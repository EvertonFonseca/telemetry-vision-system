# ============================
# HRM (prompt + imagem) + Toy Copy — v2 (mask + SDPA/FlashAttention + AdamW)
# ============================

library(torch)
library(coro)

# ---------------- Tokenizer (opcional / igual ao seu) ----------------
# (deixei como no seu código; ative se precisar)
# Tokenizer <- nn_module( ... )

safe_json <- function(txt) {
  tryCatch(jsonlite::fromJSON(txt, simplifyVector = TRUE), error = function(e) NULL)
}

prep_im_resnet <- function(img) {
  # img: [B,C,H,W], C=1 ou 3; valores 0..1
  if (img$size(2) == 1) img <- img$repeat_interleave(3, dim = 2)
  if (img$size(3) != 224 || img$size(4) != 224)
    img <- nnf_interpolate(img, size = c(224,224), mode = "bilinear", align_corners = FALSE)
  mean <- torch_tensor(c(0.485, 0.456, 0.406), device = img$device)$view(c(1,3,1,1))
  std  <- torch_tensor(c(0.229, 0.224, 0.225), device = img$device)$view(c(1,3,1,1))
  (img - mean) / std
}

# ================= Core Transformer bits =================
RMSNorm <- nn_module(
  "RMSNorm",
  initialize = function(hidden_size, eps = 1e-6) { self$eps <- eps },
  forward = function(x) {
    var <- x$pow(2)$mean(dim = -1, keepdim = TRUE)
    x / (var + self$eps)$sqrt()
  }
)

FFN_GLU <- nn_module(
  "FFN_GLU",
  initialize = function(hidden_size, ffn_hidden = NULL) {
    if (is.null(ffn_hidden)) ffn_hidden <- hidden_size * 4L
    self$w1 <- nn_linear(hidden_size, ffn_hidden, bias = FALSE)
    self$w3 <- nn_linear(hidden_size, ffn_hidden, bias = FALSE)
    self$w2 <- nn_linear(ffn_hidden, hidden_size, bias = FALSE)
  },
  forward = function(x) self$w2(self$w1(x) * self$w3(x)$sigmoid())
)

# -------- helper SDPA (usa FlashAttention quando disponível) --------
# .has_sdpa <- exists("nnf_scaled_dot_product_attention", mode = "function")
# .sdpa <- function(q, k, v, attn_mask = NULL, dropout_p = 0, is_causal = FALSE, training = TRUE) {
#   if (.has_sdpa) {
#     return(nnf_scaled_dot_product_attention(
#       q, k, v,
#       attn_mask = attn_mask,                 # bool: TRUE = mascara
#       dropout_p = if (training) dropout_p else 0,
#       is_causal = is_causal
#     ))
#   }
#   # ---- fallback manual ----
#   d <- q$size(-1)
#   attn <- torch_matmul(q, k$transpose(-2, -1)) / sqrt(as.numeric(d))
#   if (!is.null(attn_mask)) {
#     neg_inf <- torch_tensor(-Inf, device = attn$device, dtype = attn$dtype)
#     attn <- attn$masked_fill(attn_mask$expand_as(attn), neg_inf)
#   }
#   if (isTRUE(is_causal)) {
#     Lq <- attn$size(-2); Lk <- attn$size(-1)
#     causal <- torch_ones(c(Lq, Lk), dtype = torch_bool(), device = attn$device)$triu(1L)
#     attn <- attn$masked_fill(causal, torch_tensor(-Inf, device = attn$device, dtype = attn$dtype))
#   }
#   w <- nnf_softmax(attn, dim = -1)
#   if (training && dropout_p > 0) w <- nnf_dropout(w, p = dropout_p, training = TRUE)
#   torch_matmul(w, v)
# }
.has_sdpa <- exists("nnf_scaled_dot_product_attention", mode = "function")

.sdpa <- function(q, k, v, attn_mask = NULL, dropout_p = 0, is_causal = FALSE, training = TRUE) {
  if (.has_sdpa) {
    return(nnf_scaled_dot_product_attention(
      q, k, v,
      attn_mask = attn_mask,                 # bool: TRUE = mascara
      dropout_p = if (training) dropout_p else 0,
      is_causal = is_causal
    ))
  }

  # ------------ FALLBACK MANUAL ------------
  d <- q$size(-1)
  attn <- torch_matmul(q, k$transpose(-2, -1)) / sqrt(as.numeric(d))

  # 1) Máscara de padding
  if (!is.null(attn_mask)) {
    # attn_mask esperado como bool [B,1,1,Lk] (TRUE = mascarar)
    m <- attn_mask$to(dtype = torch_bool())
    # Use um ESCALAR (0-D) como valor. Em R, usar -Inf (numérico) resolve.
    attn <- attn$masked_fill(m$expand_as(attn), -Inf)
    # Se preferir, pode usar um valor grande negativo:
    # attn <- attn$masked_fill(m$expand_as(attn), -1e30)
  }

  # 2) Máscara causal (triangular superior)
  if (isTRUE(is_causal)) {
    Lq <- attn$size(-2); Lk <- attn$size(-1)
    causal <- torch_ones(c(Lq, Lk), dtype = torch_bool(), device = attn$device)$triu(1L)
    attn <- attn$masked_fill(causal, -Inf)  # ESCALAR numérico
    # ou: attn <- attn$masked_fill(causal, -1e30)
  }

  w <- nnf_softmax(attn, dim = -1)
  if (training && dropout_p > 0) w <- nnf_dropout(w, p = dropout_p, training = TRUE)
  torch_matmul(w, v)
}

# -------- MHSA com máscara e SDPA --------
MHSA <- nn_module(
  "MHSA",
  initialize = function(hidden_size, n_heads, attn_dropout = 0.0) {
    stopifnot(hidden_size %% n_heads == 0)
    self$H <- as.integer(hidden_size)
    self$h <- as.integer(n_heads)
    self$d <- as.integer(self$H / self$h)
    self$q <- nn_linear(self$H, self$H, bias = FALSE)
    self$k <- nn_linear(self$H, self$H, bias = FALSE)
    self$v <- nn_linear(self$H, self$H, bias = FALSE)
    self$o <- nn_linear(self$H, self$H, bias = FALSE)
    self$attn_dropout <- attn_dropout
  },
  # x: [B,L,H]; key_padding_mask: [B,L] (TRUE = ignorar)
  forward = function(x, key_padding_mask = NULL, is_causal = FALSE) {
    B <- x$size(1); L <- x$size(2); H <- self$H; h <- self$h; d <- self$d

    q <- self$q(x)$view(c(B, L, h, d))$transpose(2, 3)  # [B,h,L,d]
    k <- self$k(x)$view(c(B, L, h, d))$transpose(2, 3)
    v <- self$v(x)$view(c(B, L, h, d))$transpose(2, 3)

    attn_mask <- NULL
    if (!is.null(key_padding_mask)) {
      # [B,1,1,L] booleana; TRUE = mascara
      attn_mask <- key_padding_mask$unsqueeze(2)$unsqueeze(2)
    }

    ctx <- .sdpa(
      q, k, v,
      attn_mask = attn_mask,
      dropout_p = self$attn_dropout,
      is_causal = is_causal,
      training  = self$training
    ) # [B,h,L,d]

    ctx <- ctx$transpose(2, 3)$contiguous()$view(c(B, L, H))  # [B,L,H]
    self$o(ctx)
  }
)

# -------- TransEncBlock com máscara propagada --------
TransEncBlock <- nn_module(
  "TransEncBlock",
  initialize = function(hidden_size, n_heads, ffn_hidden = NULL,
                        attn_dropout = 0.0, resid_dropout = 0.0,
                        is_causal = FALSE) {
    self$attn <- MHSA(hidden_size, n_heads, attn_dropout = attn_dropout)
    self$ffn  <- FFN_GLU(hidden_size, if (is.null(ffn_hidden)) hidden_size * 4L else ffn_hidden)
    self$n1   <- RMSNorm(hidden_size)
    self$n2   <- RMSNorm(hidden_size)
    self$resid_dropout <- resid_dropout
    self$is_causal     <- is_causal
  },
  forward = function(x, key_padding_mask = NULL) {
    a <- self$attn(x, key_padding_mask = key_padding_mask, is_causal = self$is_causal)
    if (self$resid_dropout > 0 && self$training) a <- nnf_dropout(a, p = self$resid_dropout, training = TRUE)
    x <- self$n1(x + a)

    f <- self$ffn(x)
    if (self$resid_dropout > 0 && self$training) f <- nnf_dropout(f, p = self$resid_dropout, training = TRUE)
    self$n2(x + f)
  }
)

# -------- EncoderStack (encadeia a máscara) --------
EncoderStack <- nn_module(
  "EncoderStack",
  initialize = function(n_layers, hidden_size, n_heads, ffn_hidden = NULL,
                        attn_dropout = 0.0, resid_dropout = 0.0,
                        is_causal = FALSE) {
    self$layers <- nn_module_list(lapply(
      seq_len(n_layers),
      function(i) TransEncBlock(
        hidden_size, n_heads, ffn_hidden,
        attn_dropout = attn_dropout,
        resid_dropout = resid_dropout,
        is_causal = is_causal
      )
    ))
  },
  forward = function(x, key_padding_mask = NULL) {
    for (i in seq_along(self$layers)) {
      x <- self$layers[[i]](x, key_padding_mask = key_padding_mask)
    }
    x
  }
)

# ---------- I/O ----------
InputNet <- nn_module(
  "InputNet",
  initialize = function(vocab_size, hidden_size, pad_id, max_len) {
    self$embed <- nn_embedding(num_embeddings = vocab_size,
                               embedding_dim = hidden_size,
                               padding_idx = pad_id)
    self$pos   <- nn_embedding(num_embeddings = max_len + 1L, embedding_dim = hidden_size)
  },
  forward = function(x_ids) {
    B <- x_ids$size(1); L <- x_ids$size(2)
    tok <- self$embed(x_ids)  # [B,L,H]
    pos_idx0 <- torch_arange(0, L, dtype = torch_long(), device = x_ids$device)
    pos <- self$pos(pos_idx0 + 1L)$unsqueeze(1)$expand_as(tok)  # [B,L,H]
    tok + pos
  }
)

OutputHead <- nn_module(
  "OutputHead",
  initialize = function(hidden_size, vocab_size) { self$out <- nn_linear(hidden_size, vocab_size, bias = FALSE) },
  forward = function(zH) self$out(zH)          # [B,L,V]
)

QHead <- nn_module(
  "QHead",
  initialize = function(hidden_size) {
    self$lin <- nn_linear(hidden_size, 2, bias = FALSE)
  },
  forward = function(zH, key_padding_mask = NULL) {
    # zH: [B, L, H]
    if (is.null(key_padding_mask)) {
      h <- zH$mean(dim = 2)  # [B, H]
    } else {
      # key_padding_mask: [B, L], TRUE = ignorar (PAD)
      keep <- (!key_padding_mask)$to(dtype = zH$dtype)$unsqueeze(-1)  # [B,L,1]
      denom <- keep$sum(dim = 2)$clamp_min(1)                         # [B,1]
      h <- (zH * keep)$sum(dim = 2) / denom                           # [B,H]
    }
    self$lin(h)  # [B,2] -> logits (halt, continue)
  }
)

# ---------- Vision backbone (leve) ----------
VisionBackbone <- nn_module(
  "VisionBackbone",
  initialize = function(out_dim, in_ch = 3L) {
    self$fm    <- model_resnet18(pretrained = TRUE)
    self$fm$fc <- nn_linear(self$fm$fc$in_features, out_dim, bias = FALSE)
    self$fm$parameters |> purrr::walk(function(p) p$requires_grad_(TRUE))
  },
  forward = function(img) self$fm(img)
)

VisionBackboneTemporal <- nn_module(
  "VisionBackbone",
  initialize = function(out_dim, in_ch = 3L, hidden_dim = 128L, num_layers = 1L,dropout = 0.0) {
    # Backbone 2D para features por frame (sem o FC final)
    self$fm          <- model_resnet18(pretrained = TRUE)
    self$feature_dim <- self$fm$fc$in_features
    self$fm$fc       <- nn_identity()  # Remove o classificador, mantém só features
    
    # Módulo temporal: LSTM sobre a sequência de features
    self$lstm <- nn_lstm(
      input_size = self$feature_dim,
      hidden_size = hidden_dim,
      num_layers = num_layers,
      batch_first = TRUE,
      dropout = ifelse(num_layers > 1,dropout,0.0)  # Opcional, para regularização
    )

    # output final sobre o output do LSTM
    self$out <- nn_linear(hidden_dim, out_dim)
    
    # Habilita gradientes (se necessário)
    self$parameters |> purrr::walk(function(p) p$requires_grad_(TRUE))
  },
  
  forward = function(img) {
    # img: (B, T, C, H, W)
    B <- img$size(1); T <- img$size(2)
    C <- img$size(3); H <- img$size(4); W <- img$size(5)
  
    x <- img$reshape(c(B*T, C, H, W))     # (B*T, C, H, W)
    feat_bt <- self$fm(x)                  # (B*T, feature_dim)
    features <- feat_bt$reshape(c(B, T, self$feature_dim))  # (B, T, feature_dim)
  
    out <- self$lstm(features)
    lstm_out <- out[[1]]
    last_hidden <- lstm_out[,T,]         # último passo temporal
    self$out(last_hidden)
  }
)

# --------------- util: máscara de padding ---------------
make_key_padding_mask <- function(x_ids, pad_id) {
  if (is.null(pad_id)) return(NULL)
  (x_ids == pad_id)   # [B,L] booleana (TRUE = mascarar)
}

# ================= HRM (com imagem) =================
HRMRecurrent <- nn_module(
  "HRMRecurrent",
  initialize = function(hidden_size, n_layers = 2, n_heads = 4, ffn_hidden = NULL,
                        attn_dropout = 0.0, resid_dropout = 0.0, is_causal = FALSE) {
    self$enc <- EncoderStack(n_layers, hidden_size, n_heads, ffn_hidden,
                             attn_dropout = attn_dropout, resid_dropout = resid_dropout,
                             is_causal = is_causal)
  },
  forward = function(z_prev, cond_state, x_embed = NULL, key_padding_mask = NULL) {
    h <- z_prev + cond_state
    if (!is.null(x_embed)) h <- h + x_embed
    self$enc(h, key_padding_mask = key_padding_mask)
  }
)

HRM <- nn_module(
  "HRM",
  initialize = function(vocab_size, hidden_size = 256,
                        n_layers_H = 1, n_layers_L = 1,
                        n_heads = 4, ffn_hidden = NULL,
                        N_cycles = 2, T_steps = 2,
                        max_len = 64, pad_id = NULL,
                        img_channels = 1L,
                        attn_dropout = 0.0, resid_dropout = 0.0,
                        is_causal = FALSE) {
    self$hidden_size <- as.integer(hidden_size)
    self$N_cycles <- as.integer(N_cycles)
    self$T_steps  <- as.integer(T_steps)
    self$pad_id   <- pad_id

    self$fI <- InputNet(vocab_size, hidden_size, pad_id, max_len)
    #self$vision_backbone <- VisionBackbone(out_dim = hidden_size, in_ch = img_channels)
    self$vision_backbone <- VisionBackboneTemporal(out_dim = hidden_size,in_ch = img_channels)
    self$fH <- HRMRecurrent(hidden_size, n_layers_H, n_heads, ffn_hidden,
                            attn_dropout, resid_dropout, is_causal)
    self$fL <- HRMRecurrent(hidden_size, n_layers_L, n_heads, ffn_hidden,
                            attn_dropout, resid_dropout, is_causal)
    self$fO <- OutputHead(hidden_size, vocab_size)
    self$qh <- QHead(hidden_size)
    self$register_buffer("z0H", torch_zeros(1, max_len, hidden_size))
    self$register_buffer("z0L", torch_zeros(1, max_len, hidden_size))
  },

  compose_inputs = function(prompt_ids, image = NULL) {
    x_tok <- self$fI(x_ids = prompt_ids)   # [B,L,H]
    if (!is.null(image)) {
      v <- self$vision_backbone(image)                                  # [B,H]
      H <- x_tok$size(3)
      v <- v / (v$norm(dim = 2, keepdim = TRUE) + 1e-6) * sqrt(as.numeric(H))
      x_tok <- x_tok + v$unsqueeze(2)$expand_as(x_tok)                  # [B,L,H]
    }
    x_tok
  },
  # forward de inferência (no-grad)
  forward = function(prompt_ids, image, M_max = NULL, halt_margin = NULL) {
    device     <- prompt_ids$device
    prompt_ids <- prompt_ids$to(device = device)
    image      <- image$to(device = device)

    if (is.null(M_max))      M_max      <- torch_tensor(4L, device = device)
    if (is.null(halt_margin)) halt_margin <- torch_tensor(0,  device = device)

    with_no_grad({
      x_embed <- self$compose_inputs(prompt_ids, image = image)
      key_mask <- make_key_padding_mask(prompt_ids, self$pad_id)

      B <- prompt_ids$size(1); L <- prompt_ids$size(2)
      zH <- self$z0H[, 1:L, ]$expand(c(B, L, self$hidden_size))$to(device = device)
      zL <- self$z0L[, 1:L, ]$expand(c(B, L, self$hidden_size))$to(device = device)

      last_logits <- NULL
      m_used <- 0L
      for (m in seq_len(M_max$item())) {
        s <- self$hrm_step_once(zH, zL, x_embed, key_padding_mask = key_mask)
        zH <- s$zH; zL <- s$zL
        last_logits <- s$logits
        q <- s$q_logits
        probs <- nnf_softmax(q, dim = 2L)
        p_h <- probs[, 1]; p_c <- probs[, 2]
        m_used <- m
        if (as.logical((p_h >= (p_c + halt_margin))$all()$item())) break
        zH <- zH$detach(); zL <- zL$detach()
      }

      pred_ids <- torch_argmax(last_logits, dim = 3L)$to(dtype = torch_long())  # [B,L]
      pred_ids
    })
  },
  # passo interno (executa NT−1 sem grad + último com grad)
  hrm_step_once = function(zH, zL, x_embed, key_padding_mask = NULL) {
    fL <- self$fL; fH <- self$fH; fO <- self$fO; qh <- self$qh
    N  <- self$N_cycles; T <- self$T_steps
    with_no_grad({
      if (N > 1L) {
        for (cy in 1L:(N - 1L)) {
          for (t in 1L:T) zL <- fL(z_prev = zL, cond_state = zH, x_embed = x_embed, key_padding_mask = key_padding_mask)
          zH <- fH(z_prev = zH, cond_state = zL, x_embed = NULL, key_padding_mask = key_padding_mask)
        }
      }
      if (T > 1L) for (t in 1L:(T - 1L)) zL <- fL(z_prev = zL, cond_state = zH, x_embed = x_embed, key_padding_mask = key_padding_mask)
    })
    zL <- fL(z_prev = zL, cond_state = zH, x_embed = x_embed, key_padding_mask = key_padding_mask)
    zH <- fH(z_prev = zH, cond_state = zL, x_embed = NULL,   key_padding_mask = key_padding_mask)
    logits <- fO(zH); q_logits <- qh(zH,key_padding_mask = key_padding_mask)
    jit_tuple(list(zH = zH, zL = zL, logits = logits, q_logits = q_logits))
  }
)

# ---------- Passo externo (útil no treino O(M)) ----------
hrm_step_once <- function(model, zH, zL, x_embed, key_padding_mask = NULL) {
  fL <- model$fL; fH <- model$fH; fO <- model$fO; qh <- model$qh
  N <- model$N_cycles; T <- model$T_steps
  with_no_grad({
    if (N > 1L) {
      for (cy in 1L:(N - 1L)) {
        for (t in 1L:T) zL <- fL(z_prev = zL, cond_state = zH, x_embed = x_embed, key_padding_mask = key_padding_mask)
        zH <- fH(z_prev = zH, cond_state = zL, x_embed = NULL, key_padding_mask = key_padding_mask)
      }
    }
    if (T > 1L) for (t in 1L:(T - 1L)) zL <- fL(z_prev = zL, cond_state = zH, x_embed = x_embed, key_padding_mask = key_padding_mask)
  })
  zL <- fL(z_prev = zL, cond_state = zH, x_embed = x_embed, key_padding_mask = key_padding_mask)
  zH <- fH(z_prev = zH, cond_state = zL, x_embed = NULL,   key_padding_mask = key_padding_mask)
  logits <- fO(zH); q_logits <- qh(zH,key_padding_mask = key_padding_mask)
  list(zH = zH, zL = zL, logits = logits, q_logits = q_logits)
}

# ================== Losses do paper ==================
paper_seq_loss_m <- function(segments_full, y_ids, m, pad_id = NULL,ignore_first_pos = TRUE) {
  logits_m <- segments_full[[m]]$logits
  logp <- nnf_log_softmax(logits_m, dim = -1)
  nll  <- nnf_nll_loss(logp$transpose(2,3), y_ids, reduction = "none")
  mask <- if (is.null(pad_id)) torch_ones_like(y_ids, dtype = torch_float())
          else (y_ids != pad_id)$to(dtype = torch_float())
  (nll * mask)$sum() / torch_clamp(mask$sum(), min = 1)
}

halt_match_masked <- function(logits_m, y_ids, pad_id = NULL) {
  pred  <- torch_argmax(logits_m, dim = 3L)
  valid <- if (is.null(pad_id)) torch_ones_like(y_ids, dtype = torch_bool()) else (y_ids != pad_id)
  ok <- (pred == y_ids) | !valid
  cnt_true <- torch_sum(ok$to(dtype = torch_float()), dim = 2L)
  (cnt_true == as.numeric(ok$size(2)))$to(dtype = torch_float())
}

paper_act_targets <- function(q_next_logits, logits_curr, y_ids,
                              m, M_max, pad_id = NULL, q_curr_logits = NULL) {
  with_no_grad({
    dev <- if (!is.null(q_next_logits)) q_next_logits$device else logits_curr$device
    B   <- y_ids$size(1)

    pred  <- torch_argmax(logits_curr, dim = 3L)                 # [B,L]
    valid <- if (is.null(pad_id)) torch_ones_like(y_ids, dtype = torch_bool()) else (y_ids != pad_id)
    ok_seq <- (pred == y_ids) | !valid
    halt_t <- (torch_sum(ok_seq$to(dtype = torch_float()), dim = 2L) ==
               as.numeric(ok_seq$size(2)))$to(device = dev, dtype = torch_float())$reshape(c(B))

    cont_t <- NULL
    if (!is.null(q_next_logits)) {
      p_next <- q_next_logits$sigmoid()  # [B,2]
      if (m < M_max) {
        mx <- torch_max(p_next, dim = 2L)
        cont_t <- (if (is.list(mx)) mx[[1]] else mx)$reshape(c(B))
      } else {
        cont_t <- p_next[, 1]$reshape(c(B))
      }
    }
    if (is.null(cont_t)) {
      if (is.null(q_curr_logits)) stop("paper_act_targets: q_next ausente e q_curr_logits=NULL")
      p_curr <- q_curr_logits$sigmoid()
      cont_t <- p_curr[, 1]$reshape(c(B))
    }
    torch_cat(list(halt_t$unsqueeze(2), cont_t$unsqueeze(2)), dim = 2L)
  })
}

# ============ Treino do paper (O(M)) ============
train_epoch_paper <- function(
  model, dl, optimizer, pad_id,
  device = "cuda", M_max = 3L, lambda_q = 1.0,
  max_grad_norm = 1.0, scheduler_step = NULL, debug = FALSE) {

  model$to(device = device); model$train()
  tot_loss <- 0; tot_ce <- 0; tot_actq <- 0; n_batch <- 0L
  count_loop <- 1; lengthdl <- length(dl)
  pb <- utils::txtProgressBar(min = 0, max = lengthdl, style = 3)
  #b <- train_dl$.iter()$.next()
  coro::loop(for (b in dl) {
    setTxtProgressBar(pb, count_loop)

    prompt <- b$prompt$to(device = device)
    target <- b$target$to(device = device)
    img    <- b$img$to(device = device)

    B <- prompt$size(1); L <- prompt$size(2)
    zH <- model$z0H[, 1:L, ]$expand(c(B, L, model$hidden_size))$to(device = device)
    zL <- model$z0L[, 1:L, ]$expand(c(B, L, model$hidden_size))$to(device = device)

    key_mask   <- make_key_padding_mask(prompt, pad_id)
    last_total <- last_ce <- last_actq <- NA_real_

    for (m in seq_len(M_max)) {
      optimizer$zero_grad()
    
      x_embed <- model$compose_inputs(prompt_ids = prompt, image = img)

      s <- hrm_step_once(model, zH, zL, x_embed, key_padding_mask = key_mask)
      zH <- s$zH; zL <- s$zL
      logits_m <- s$logits; q_m <- s$q_logits

      with_no_grad({ s_next <- hrm_step_once(model, zH$detach(), zL$detach(), x_embed, key_padding_mask = key_mask) })
      q_next <- s_next$q_logits

      ce   <- paper_seq_loss_m(list(list(logits = logits_m)), target, m = 1, pad_id = pad_id)
      G    <- paper_act_targets(q_next, logits_m, target, m, M_max, pad_id, q_curr_logits = q_m)
      actq <- nnf_binary_cross_entropy_with_logits(q_m, G, reduction = "mean")
      loss <- ce + lambda_q * actq

      loss$backward()
      nn_utils_clip_grad_norm_(model$parameters, max_grad_norm)

      optimizer$step()
      if (!is.null(scheduler_step)) scheduler_step()

      last_total <- as.numeric(loss$item())
      last_ce    <- as.numeric(ce$item())
      last_actq  <- as.numeric(actq$item())

      zH <- zH$detach(); zL <- zL$detach()
    }

    tot_loss <- tot_loss + last_total
    tot_ce   <- tot_ce   + last_ce
    tot_actq <- tot_actq + last_actq
    n_batch  <- n_batch + 1L
    count_loop <- count_loop + 1
  })
  close(pb)

  list(
    loss = if (n_batch == 0) 0 else tot_loss / n_batch,
    ce   = if (n_batch == 0) 0 else tot_ce   / n_batch,
    actq = if (n_batch == 0) 0 else tot_actq / n_batch
  )
}

# ---------- Scheduler ----------
make_warmup_const <- function(base_lr, epochs, steps_per_epoch, warmup_ratio = 0.05) {
  total <- epochs * steps_per_epoch
  warm  <- max(1L, as.integer(warmup_ratio * total))
  function(step) if (step < warm) base_lr * (step + 1) / warm else base_lr
}

make_warmup_cosine <- function(base_lr, total_steps,
                               warmup_steps = as.integer(0.05 * total_steps),
                               min_lr = 1e-6) {
  function(step) {
    if (step <= warmup_steps) {
      # warmup linear
      return(base_lr * step / max(1, warmup_steps))
    }
    # cosine decay até min_lr
    t  <- (step - warmup_steps) / max(1, total_steps - warmup_steps)
    lr <- base_lr * (0.5 * (1 + cos(pi * t)))
    max(min_lr, lr)
  }
}


set_optimizer_lr <- function(optimizer, lr_new) {
  for (i in seq_along(optimizer$param_groups)) optimizer$param_groups[[i]]$lr <- lr_new
}

# =========================
# Inferência e comparação
# =========================
decode_ids_to_string <- function(tokenizer, ids) {
  if (inherits(ids, "torch_tensor")) ids <- as.numeric(ids$to(device = "cpu"))
  end_id <- tokenizer$end_id; pad_id <- tokenizer$pad_id
  out <- character()
  for (i in ids) {
    if (i == pad_id) break
    tok <- tokenizer$id2tok[[as.character(i)]]
    if (identical(tok, "<END>")) break
    if (!tok %in% c("<PAD>","<START>","<END>","<UNK>")) out <- c(out, tok)
  }
  paste0(out, collapse = "")
}

hrm_predict <- function(model, prompt_ids, image, M_max = 3L, device = "cuda", halt_margin = 0.0) {
  model$to(device = device); model$eval()
  prompt_ids <- prompt_ids$to(device = device)
  image      <- image$to(device = device)

  with_no_grad({
    x_embed  <- model$compose_inputs(prompt_ids, image = image)
    key_mask <- make_key_padding_mask(prompt_ids, model$pad_id)

    B <- prompt_ids$size(1); L <- prompt_ids$size(2)
    zH <- model$z0H[, 1:L, ]$expand(c(B, L, model$hidden_size))$to(device = device)
    zL <- model$z0L[, 1:L, ]$expand(c(B, L, model$hidden_size))$to(device = device)

    last_logits <- NULL; m_used <- 0L
    for (m in seq_len(M_max)) {
      s <- hrm_step_once(model, zH, zL, x_embed, key_padding_mask = key_mask)
      zH <- s$zH; zL <- s$zL
      last_logits <- s$logits
      q <- s$q_logits
      probs <- nnf_softmax(q, dim = 2L)
      p_h <- probs[, 1]; p_c <- probs[, 2]
      m_used <- m
      if (as.logical((p_h >= (p_c + halt_margin))$all()$item())) break
      zH <- zH$detach(); zL <- zL$detach()
    }

    pred_ids <- torch_argmax(last_logits, dim = 3L)$to(dtype = torch_long())  # [B,L]
    jit_tuple(list(pred_ids = pred_ids, m_used = m_used))
  })
}

compare_batch <- function(model, dl, tokenizer, n = 8L, M_max = 3L, device = "cuda", halt_margin = 0.0) {
  it <- dataloader_make_iter(dl)
  b  <- dataloader_next(it)
  prompt <- b$prompt; target <- b$target; img <- b$img

  pred <- hrm_predict(model, prompt, image = img, M_max = M_max, device = device, halt_margin = halt_margin)
  pred_ids <- pred$pred_ids
  B <- min(n, as.integer(target$size(1)))

  cat(sprintf("== Comparação (M_max=%d, usados até m=%d) ==\n", M_max, pred$m_used))
  for (i in seq_len(B)) {
    tgt_str  <- decode_ids_to_string(tokenizer, target[i, ])
    pred_str <- decode_ids_to_string(tokenizer, pred_ids[i, ])
    ok <- identical(tgt_str, pred_str); mark <- if (ok) "✓" else "✗"
    cat(sprintf("[%02d] %s\n  target: %s\n  pred  : %s\n", i, mark, tgt_str, pred_str))
  }
}

exact_match_batch <- function(model, dl, tokenizer, M_max = 3L, device = "cuda", halt_margin = 0.05) {
  model$eval()
  it <- dataloader_make_iter(dl)
  total <- 0L; correct <- 0L

  repeat {
    b <- tryCatch(dataloader_next(it), error = function(e) NULL)
    if (is.null(b)) break

    pr <- hrm_predict(model, b$prompt$to(device = device), b$img$to(device = device),
                      M_max = M_max, device = device, halt_margin = halt_margin)

    pred_ids <- pr$pred_ids
    B <- as.integer(pred_ids$size(1))
    for (i in seq_len(B)) {
      tgt <- decode_ids_to_string(tokenizer, b$target[i, ])
      out <- decode_ids_to_string(tokenizer, pred_ids[i, ])
      if (identical(tgt, out)) correct <- correct + 1L
    }
    total <- total + B
  }

  list(acc = if (total == 0L) 0 else correct / total, total = total, correct = correct)
}

avg_m_used <- function(model, dl, M_max = 3L, device = "cuda", halt_margin = 0.05) {
  model$eval()
  it <- dataloader_make_iter(dl)
  nb <- 0L; sum_m <- 0L

  repeat {
    b <- tryCatch(dataloader_next(it), error = function(e) NULL)
    if (is.null(b)) break
    pr <- hrm_predict(model, b$prompt$to(device = device), b$img$to(device = device),
                      M_max = M_max, device = device, halt_margin = halt_margin)
    sum_m <- sum_m + pr$m_used
    nb <- nb + 1L
  }

  if (nb == 0L) NA_real_ else sum_m / nb
}

print_target_pred <- function(model, dl, tokenizer,
                              n = 8L, M_max = 3L,
                              device = "cuda", halt_margin = 0.05,
                              show_prompt = FALSE, show_m_used = TRUE,loop_max = NULL) {
  stopifnot(exists("decode_ids_to_string"), exists("hrm_predict"))
  model$eval()

  it <- dataloader_make_iter(dl)
  counter <- 1
  repeat {

    if(!is.null(loop_max)){
        if(counter > loop_max) break
    }
    
    b  <- dataloader_next(it)

    if(is.null(b)) break

    prompt <- b$prompt; target <- b$target; img <- b$img

    pr <- hrm_predict(model, prompt$to(device = device), img$to(device = device),
                      M_max = M_max, device = device, halt_margin = halt_margin)

    pred_ids <- pr$pred_ids
    B <- min(n, as.integer(target$size(1)))

    cat(sprintf("== Target vs Pred (n=%d, M_max=%d%s, halt_margin=%.3f) ==\n",
                B, M_max,
                if (show_m_used && !is.null(pr$m_used)) sprintf(", m_used=%d", pr$m_used) else "",
                halt_margin))

    shorten <- function(x, k = 240L) { x <- as.character(x); if (nchar(x) > k) paste0(substr(x, 1, k - 3L), "...") else x }

    for (i in seq_len(B)) {
      tgt_str  <- tokenizer$dencoder(target[i, ], stop_end = TRUE)
      pred_str <- tokenizer$dencoder(pred_ids[i, ], stop_end = TRUE)
      mark <- if (identical(tgt_str, pred_str)) "✓" else "✗"
      cat(sprintf("[%02d] %s\n", i * counter, mark))
      if (show_prompt) {
        prm_str <- tokenizer$dencoder(prompt[i, ], stop_end = TRUE)
        cat("  prompt: ", shorten(prm_str), "\n", sep = "")
      }
      cat("  target: ", shorten(tgt_str),  "\n", sep = "")
      cat("  pred  : ", shorten(pred_str), "\n\n", sep = "")
    }
    counter <- counter + 1
  }
}

grad_table <- function(model) {
  rows <- list()
  namesparam <- names(model$named_parameters())
  params     <- model$named_parameters()
  for (i in seq_along(params)) {
    name <- namesparam[i]; p <- params[[i]]; hasg <- !is.null(p$grad)
    rows[[length(rows)+1]] <- data.frame(
      name = name,
      shape = paste(as.integer(p$size()), collapse="x"),
      requires_grad = p$requires_grad,
      has_grad = hasg,
      grad_norm = if (hasg) as.numeric(p$grad$norm(p=2)$item()) else NA_real_,
      grad_mean = if (hasg) as.numeric(p$grad$abs()$mean()$item()) else NA_real_,
      grad_max  = if (hasg) as.numeric(p$grad$abs()$max()$item())  else NA_real_,
      param_norm = as.numeric(p$data()$norm(p=2)$item()),
      stringsAsFactors = FALSE
    )
  }
  do.call(rbind, rows)
}

block_tag <- function(param_name) {
  if (grepl("^fI\\.", param_name))          "InputNet"
  else if (grepl("^vision_backbone", param_name)) "VisionBackbone"
  else if (grepl("^fH\\.", param_name))     "HRM_H"
  else if (grepl("^fL\\.", param_name))     "HRM_L"
  else if (grepl("^fO\\.", param_name))     "OutputHead"
  else if (grepl("^qh\\.", param_name))     "QHead"
  else "Other"
}
grad_by_block <- function(gt) {
  gt$block <- vapply(gt$name, block_tag, character(1))
  aggregate(list(grad_sum = ifelse(is.na(gt$grad_norm), 0, gt$grad_norm)),
            by = list(block = gt$block), FUN = sum)
}
total_grad_norm <- function(model) {
  s <- 0
  params <- model$named_parameters()
  for (i in seq_along(params)) {
    p <- params[[i]]
    if (!is.null(p$grad)) s <- s + (as.numeric(p$grad$norm(p=2)$item())^2)
  }
  sqrt(s)
}
