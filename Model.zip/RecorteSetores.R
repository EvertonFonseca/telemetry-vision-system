library(shiny)
library(shinyjs)
library(imager)

ui <- fluidPage(
  useShinyjs(),
  titlePanel("Desenhar Polígono em Imagem"),
  sidebarLayout(
    sidebarPanel(
      fileInput("image", "Carregar Imagem", accept = c("image/jpeg", "image/png")),
      actionButton("clear", "Limpar Polígono"),
      actionButton("close", "Fechar Polígono")
    ),
    mainPanel(
      plotOutput("imagePlot", click = "plot_click"),
      verbatimTextOutput("coords")
    )
  )
)

server <- function(input, output, session) {
  # Variáveis reativas para armazenar coordenadas e status do polígono
  coords <- reactiveValues(points = data.frame(x = numeric(0), y = numeric(0)), closed = FALSE)
  
  # Carregar e exibir a imagem
  output$imagePlot <- renderPlot({
    req(input$image)
    img <- load.image(input$image$datapath)
    plot(img, axes = FALSE)
    
    # Desenhar pontos e linhas do polígono
    if (nrow(coords$points) > 0) {
      points(coords$points$x, coords$points$y, col = "red", pch = 19, cex = 1.5)
      if (nrow(coords$points) > 1) {
        lines(coords$points$x, coords$points$y, col = "red", lwd = 2)
        if (coords$closed) {
          lines(c(coords$points$x[nrow(coords$points)], coords$points$x[1]),
                c(coords$points$y[nrow(coords$points)], coords$points$y[1]),
                col = "red", lwd = 2)
        }
      }
    }
  })
  
  # Capturar cliques na imagem
  observeEvent(input$plot_click, {
    if (!coords$closed) {
      coords$points <- rbind(coords$points, data.frame(x = input$plot_click$x, y = input$plot_click$y))
    }
  })
  
  # Fechar o polígono
  observeEvent(input$close, {
    if (nrow(coords$points) > 2) {
      coords$closed <- TRUE
    }
  })
  
  # Limpar o polígono
  observeEvent(input$clear, {
    coords$points <- data.frame(x = numeric(0), y = numeric(0))
    coords$closed <- FALSE
  })
  
  # Exibir coordenadas
  output$coords <- renderPrint({
    if (nrow(coords$points) > 0) {
      cat("Coordenadas do Polígono:\n")
      print(coords$points)
    } else {
      cat("Nenhum ponto selecionado.\n")
    }
  })
}

shinyApp(ui, server)