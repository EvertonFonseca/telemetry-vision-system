library(torch)
library(torchvision)
library(tidyverse)
library(magick)
library(gtools)

path <- "data"
subs <- list.dirs(path,full.names = T,recursive = F)

df <- tibble(dir_path = subs) |> 
      mutate(data = map(dir_path,function(x){
        
       images    = mixedsort(list.files(x,full.names = T,pattern = "image"))
       arquivos  = basename(images)
       #timer     = map_vec(str_split(str_remove(arquivos,".png"),"_"),~ as.numeric(.x[2]))
       masks     = mixedsort(list.files(x,full.names = T,pattern = "mask")) 
       descricao = jsonlite::read_json(list.files(x,full.names = T,pattern = ".json"))
        
    tibble(id         = x,
           images     = images,
           masks      = list(masks),
           timer      = 1:length(arquivos),
           camera     = "A",
           maquina    = descricao$maquina,
           desc       = list(descricao)
          )
      })) |> 
    unnest(data)

Dataset <- dataset(
  name = "DatasetMaquinas",
  initialize = function(df,tokenizer,window = 5,size = 256L,test = F) {
  
   self$df        <- df
   self$tokenizer <- tokenizer
   self$window    <- max(0,window - 1)
   self$size      <- size
   self$test      <- test

  },
  .getitem = function(index){
  
   idT          <- self$df$id[index]
   masks        <- self$df$masks[[index]]
   timerT       <- self$df$timer[index]
   maquinaT     <- self$df$maquina[index]
   cameraT      <- self$df$camera[index]
   past_window  <- (timerT - self$window)

   obs <- self$df |>
          filter(id == idT) |> 
          filter(timer >= ifelse(past_window < 0,1,past_window) & 
                 timer <= timerT & (maquina == maquinaT & camera %in% cameraT))  
  
   if(past_window <= 0){
      chunk <- first(obs)
      for(i in 0:abs(past_window)) obs <- rbind(chunk,obs)
   }
  
   desc       <- last(obs$desc)
   imgs       <- obs$images
  #  components <- map(masks,function(mask){
  #     frames <- list()
  #     for(i in seq_along(imgs)){
  #         img <- imgs[i] 
  #         frames[[i]] <- self$crop_image_from_mask_bbox(img,mask,c(self$size,self$size))
  #     }
  #     x <- torch_stack(frames,dim = 1L)
  #     x <- self$rotate(x)
  #     x <- self$flip(x)
  #     x <- self$jitterColor(x) 
  #     x 
  #   })
    x <- NULL
    for(m in seq_along(masks)){
      mask <- masks[[m]]
      frames <- list()
      for(i in seq_along(imgs)){
          img <- imgs[i] 
          frames[[i]] <- self$crop_image_from_mask_bbox(img,mask,c(self$size,self$size))
      }
      y <- torch_stack(frames,dim = 1L)
      y <- self$rotate(y)
      y <- self$flip(y)
      y <- self$jitterColor(y) 
      if(is.null(x)){
          x <- y
      }else{
          x <- x + y
      }
    
    }

   x <- x / length(masks)
    
   if(x$size()[2] == 1L){
     x <- x$repeat_interleave(3L, dim = 2L)  # [T,3,H,W]
   }
   
   prompt = paste0('\"maquina\":\"',desc$maquina,'\"') 
   #image_read(as.array(components[[2]][1,,,]$permute(c(2,3,1))))
   list(prompt = self$tokenizer$encoder(prompt),
        images = x, # [T,C,H,W]
        target_token = self$tokenizer$encoder(jsonlite::toJSON(desc,auto_unbox = T),add_end = TRUE))
  },
  .length = function() {
    nrow(self$df)
  },
  crop_image_from_mask_bbox = function(
    image_path,
    mask_path,
    resize = c(256, 256),
    grayscale = FALSE,
    margin = 0L,
    eps = 1e-9,
    fallback_threshold = NULL
  ) {
    # 1) Lê a máscara como matriz 0..1 (assume grayscale ou RGB convertido para gray)
    mask_arr <- base_loader(mask_path)
    if (length(dim(mask_arr)) == 3) {
      # Converte RGB para grayscale (média dos canais)
      mask_arr <- rowMeans(mask_arr, dims = 2)
    }
    H <- nrow(mask_arr)
    W <- ncol(mask_arr)
    mat01 <- torch::torch_tensor(mask_arr, dtype = torch::torch_float())

    # 2) Binário: pixels >= 1 (com tolerância)
    bin <- mat01 >= (1 - eps)

    #Fallback se não houver nenhum 1 exato
    if (
      torch::torch_count_nonzero(bin)$item() == 0 && !is.null(fallback_threshold)
    ) {
      bin <- mat01 > fallback_threshold # refaça com limiar no tensor (em vez de mat01)
    }
    if (torch::torch_count_nonzero(bin)$item() == 0) {
      return(NULL)
    }

    # 3) Encontra linhas/colunas com pelo menos um 1
    row_sums <- torch::torch_sum(bin, dim = 2)
    col_sums <- torch::torch_sum(bin, dim = 1)
    ys <- torch::torch_nonzero(row_sums > 0) + 1L # Índices 1-based
    xs <- torch::torch_nonzero(col_sums > 0) + 1L
    ymin <- torch::torch_min(ys)$item()
    ymax <- torch::torch_max(ys)$item()
    xmin <- torch::torch_min(xs)$item()
    xmax <- torch::torch_max(xs)$item()

    # 4) Aplica margem com clipping
    xmin <- max(1L, xmin - margin)
    ymin <- max(1L, ymin - margin)
    xmax <- min(W, xmax + margin)
    ymax <- min(H, ymax + margin)

    # 5) Lê a imagem original
    image_arr <- base_loader(image_path)
    # Converte para tensor [C, H, W] se RGB; se grayscale, ajuste conforme necessário
    if (length(dim(image_arr)) == 2) {
      image_tensor <- torch::torch_tensor(image_arr)$unsqueeze(1) # [1, H, W]
    } else {
      image_tensor <- torch::torch_tensor(
        aperm(image_arr, c(3, 1, 2)),
        dtype = torch::torch_float()
      ) # [C, H, W]
    }

    # 6) Crop o tensor
    cropped_tensor <- image_tensor[, ymin:ymax, xmin:xmax]
    if (!is.null(resize)) {
      cropped_tensor <- torchvision::transform_resize(cropped_tensor, resize)
    }

    if(grayscale){
      cropped_tensor <- torch_unsqueeze(torchvision::transform_rgb_to_grayscale(cropped_tensor),1L)
    }
    return(cropped_tensor)
  },addGaussianNoise = function(tensor,mean = 0.0,std = 1.0,per = 0.2){
      
      if(runif(1) <= per & !self$test){
        torch_clamp(tensor + torch_randn(tensor$size()) * std + mean,min = 0,max = 1)
      }else{
        tensor
      }
    },
    rotate = function(img,rot_param = 10) {
      rnd_flip <- runif(1)
      if (rnd_flip >= 0.51) {
        rnd_rot <- runif(1, 1 - rot_param, 1 + rot_param)
        n       <- img$size()[1]
        for(i in 1:n){
         img[i,1,,] <- transform_rotate(img[i,1,,,drop = F],angle = rnd_rot) 
        }
      }
      img
    },
    flip = function(img, flip_param =  0.5) {
      status = FALSE
      rnd_flip <- runif(1)
      if (rnd_flip >= flip_param) {
        img <- transform_hflip(img)
        status <- TRUE
      }
      img
    },
    jitterColor = function(img) {
      
      if (runif(1) <= 0.6 & img$size()[1] > 1) {
        img  <- transform_color_jitter(img,brightness = c(0.5,1.0),contrast = c(0.5,1.0),saturation = c(0.5,1.0))
      }else if(runif(1) <= 0.6){
        img  <- img * runif(1,0.3,0.8)
      }
      img
    })

objs <- unique(c(unlist(map(df$desc,~ names(.x))),unlist(map(df$desc,~ .x$maquina))))
# Define the vocabulary
vocab <- c(
  "<UNK>","<START>","<PAD>","<END>",
  "action","start","stop","obj","status","stading","moving","its","of","camera","left","front","right","back",
  paste(objs),
  "objeto","box","dist","_","operation",
  "Analyze","the","image","and","only","return","\"","\'","a","JSON","in","the","on","off","alto","medio","baixo","vazio",
  "format","[","]","{","}",":",",",".",
  "0","1","2","3","4","5","6","7","8","9"," "
)
vocab2 <- c("<PAD>", "<START>", "<END>", "<UNK>",LETTERS,
           letters, as.character(0:9),
           "{","}","\"",":",",",".")

vocab <- unique(c(vocab,vocab2))

vocab_size  <- length(vocab)
token_to_id <- setNames(seq_along(vocab), vocab)
id_to_token <- setNames(vocab, seq_along(vocab))

# Define the Tokenizer class

# Define the Tokenizer class
Tokenizer <- nn_module(
  "Tokenizer",

  initialize = function(vocab, token_to_id, id_to_token,max_len = 50L) {
    self$vocab <- vocab
    self$vocab_size <- length(vocab)
    self$token_to_id <- token_to_id
    self$id_to_token <- id_to_token
    self$pad_token_id <- token_to_id["<PAD>"]
    self$end_token_id <- token_to_id["<END>"]
    self$start_token_id <- token_to_id["<START>"]
    self$unk_token_id <- token_to_id["<UNK>"]
    self$max_len = max_len
  },

  encoder = function(input, add_start = FALSE, add_end = TRUE) {
    if (is.list(input)) {
      input <- jsonlite::toJSON(input, auto_unbox = TRUE)
    }
    if (!is.character(input)) {
      input <- as.character(input)
    }
    if (length(input) > 1) {
      input <- paste(input, collapse = " ")
    }

    # Substitui todos espaços por o token especial " "
    input <- gsub(" ", " <SPACE> ", input, fixed = TRUE)

    # Split robusto: igual antes, mas agora separa <SPACE> como um token
    tokens <- unlist(strsplit(
      input,
      "(?=[,.:;{}\\[\\]'\"\\(\\)])|(?<=[,.:;{}\\[\\]'\"\\(\\)])|\\s+",
      perl = TRUE
    ))
    tokens <- tokens[tokens != "" & tokens != " "]
    tokens <- unlist(lapply(tokens, function(tok) {
      if (tok == "<SPACE>") {
        return(" ")
      } # mapeia para o token espaço
      if (grepl("^[0-9]+$", tok)) strsplit(tok, "")[[1]] else tok
    }))
    if (add_start) {
      tokens <- c("<START>", tokens)
    }
    if (add_end) {
      tokens <- c(tokens, "<END>")
    }
    ids <- sapply(tokens, function(t) {
      if (t %in% names(self$token_to_id)) {
        self$token_to_id[[t]]
      } else {
        self$unk_token_id
      }
    })
    torch_tensor(ids, dtype = torch_long())
  },

  dencoder = function(ids, remove_special = TRUE, stop_end = FALSE) {
    if (inherits(ids, "torch_tensor")) {
      ids <- as.numeric(ids$cpu())
    }

    tokens <- sapply(ids, function(i) self$id_to_token[[as.character(i)]])

    # Corta na primeira ocorrência de <END> (sem incluí-lo)
    if (isTRUE(stop_end)) {
      end_pos <- which(tokens == "<END>")[1]
      if (!is.na(end_pos)) tokens <- tokens[seq_len(end_pos - 1)]
    }

    # Remove especiais (exceto <END>, já removido se stop_end=TRUE)
    if (isTRUE(remove_special)) {
      tokens <- tokens[!(tokens %in% c("<PAD>", "<START>", "<END>"))]
    }

    if (length(tokens) == 0) return("")

    out <- ""
    i <- 1
    while (i <= length(tokens)) {
      tok  <- tokens[i]
      prev <- if (i > 1) tokens[i - 1] else ""

      # 1) token de espaço explícito
      if (tok == " ") {
        # só coloca espaço se último caractere de 'out' não for espaço
        if (nchar(out) == 0 || substr(out, nchar(out), nchar(out)) != " ") {
          out <- paste0(out, " ")
        }
        i <- i + 1

      # 2) números (sequência de dígitos e '.')
      } else if (tok %in% as.character(0:9)) {
        num <- tok
        j <- i + 1
        while (j <= length(tokens) && (tokens[j] %in% c(as.character(0:9), "."))) {
          num <- paste0(num, tokens[j])
          j <- j + 1
        }
        # Se último char já é espaço ou é início de string, concatena direto
        last_char <- if (nchar(out) > 0) substr(out, nchar(out), nchar(out)) else ""
        if (nchar(out) == 0 || last_char %in% c(" ", "(", "[", "{", ":", "'", "\"")) {
          out <- paste0(out, num)
        } else {
          out <- paste(out, num)
        }
        i <- j
        # (removido o bloco que adicionava um espaço extra após número)

      # 3) pontuação que gruda à esquerda (sem espaço antes)
      } else if (tok %in% c(",", ".", ":", ";", "]", "}", ")", "'", "\"")) {
        out <- paste0(out, tok)
        i <- i + 1

      # 4) token após abertura de parênteses/chaves/colchetes/aspas → sem espaço antes
      } else if (i > 1 && tokens[i - 1] %in% c("[", "{", "(", "'", "\"")) {
        out <- paste0(out, tok)
        i <- i + 1

      # 5) caso geral: só insira espaço se último char não for espaço
      } else {
        last_char <- if (nchar(out) > 0) substr(out, nchar(out), nchar(out)) else ""
        if (nchar(out) == 0 || last_char %in% c("(", "[", "{", ":", "'", "\"", " ")) {
          out <- paste0(out, tok)  # não duplica espaços
        } else {
          out <- paste(out, tok)   # insere um espaço entre palavras
        }
        i <- i + 1
      }
    }

    trimws(out)
  },
  get_vocab = function() self$vocab,
  get_vocab_size = function() self$vocab_size,
  get_pad_token_id = function() self$pad_token_id,
  get_end_token_id = function() self$end_token_id,
  get_start_token_id = function() self$start_token_id,
  get_unk_token_id = function() self$unk_token_id,
  set_max_len = function(val) { self$max_len <- val },
  get_max_len = function() { self$max_len }
)

collate_fn <- function(batch) {

  pad_token_id = tokenizer$get_pad_token_id()
  max_len      = tokenizer$get_max_len()

  trunc_pad <- function(t) {
    # t: 1D Long tensor
    len <- t$size(1)
    if (len > max_len) {
      t[1:max_len]
    } else if (len < max_len) {
      pad <- torch_full(c(max_len - len), pad_token_id, dtype = torch_long())
      torch_cat(list(t, pad), dim = 1)
    } else t
  }

  imgs    <- lapply(batch, `[[`, "images")
  tokens  <- lapply(batch, `[[`, "target_token")
  prompts <- lapply(batch, `[[`, "prompt")

  lens_tgt <- sapply(tokens, function(t) min(as.integer(t$size(1)), max_len))
  lens_prm <- sapply(prompts, function(t) min(as.integer(t$size(1)), max_len))

  batch_img     <- torch_stack(imgs)
  batch_targets <- torch_stack(lapply(tokens, trunc_pad))
  batch_prompts <- torch_stack(lapply(prompts, trunc_pad))

  list(
    img      = batch_img,        # [B,G,T,C,H,W] no seu caso
    prompt   = batch_prompts,    # <- ENTRA no HRM como x_ids
    target   = batch_targets    # <- sequência alvo (com <END> e PAD)
  )
}

tokenizer <- Tokenizer(vocab,token_to_id, id_to_token,max_len = 50)
train     <- Dataset(df,tokenizer = tokenizer,window = 3)

train_dl <- dataloader(
  dataset = train,
  batch_size = 5,
  shuffle = TRUE,
  pin_memory = TRUE, # move mais rápido p/ GPU
  collate_fn = collate_fn,
  num_workers = 8,
  worker_globals = c("tokenizer"),
  worker_packages = c("torch", "torchvision","dplyr","purrr")
)

# ================== Instanciação + treino (exemplo) ==================
source("Hrm.R")
device <- ifelse(cuda_is_available(), "cuda", "cpu")
model <- HRM(
  vocab_size  = tokenizer$get_vocab_size(),
  hidden_size = 128,
  n_layers_H  = 2,
  n_layers_L  = 2,
  n_heads     = 4,
  N_cycles    = 2,
  T_steps     = 2,
  max_len     = tokenizer$get_max_len(),
  pad_id      = tokenizer$get_pad_token_id(),
  img_channels = 1L
)$to(device = device)

epochs    <- 8
base_lr   <- 2e-4
M_max     <- 4L
optimizer <- optim_adam(model$parameters, lr = base_lr, betas = c(0.9, 0.95), eps = 1e-8, weight_decay = 0)
steps_per_ep <- length(train_dl)
sched_fn     <- make_warmup_cosine(base_lr, epochs, steps_per_ep)
step_counter <- 0L
scheduler_step <- function() { step_counter <<- step_counter + 1L; set_optimizer_lr(optimizer, sched_fn(step_counter)) }

lambda_schedule <- function(ep) {
  if (ep <= 2) 0.3
  else if (ep <= 5) 0.6
  else 1.0
}

# Antes de iniciar o treinamento, verifique se há um checkpoint
start_epoch <- 1
ce_mem      <- 999999
checkpoint_file <- "checkpoint.ptx"
if (file.exists(checkpoint_file)) {
  message("Loading training state from checkpoint...")
  checkpoint <- torch_load(checkpoint_file)
  
  # Restaurar o estado do modelo
  model$load_state_dict(checkpoint$model_state)
  model$to(device = device)
  
  # Restaurar o estado do otimizador
  optimizer_state <- checkpoint$optimizer_state
  for(i in seq_along(optimizer_state$state)){
      state <- optimizer_state$state[[i]]
      for(j in 1:length(state)){
          feature <- state[[j]]
          if(any(class(feature) %in% "torch_tensor")){
            optimizer_state$state[[i]][[j]] <- feature$to(device = device)
          }
      }
  }
  optimizer$load_state_dict(optimizer_state)
  # Restaurar outras variáveis
  step_counter <- checkpoint$step_counterA
  ce_mem       <- checkpoint$ce_mem
  start_epoch  <- checkpoint$epoch + 1  # Começar na próxima época
} 

for (epoch in start_epoch:epochs) {

  if(ce_mem <= 0.02){
    message("Stop Earling ...")
    break
  }

  tr <- train_epoch_paper(
    model, dl = train_dl, optimizer = optimizer,
    pad_id = tokenizer$get_pad_token_id(),
    device = device, M_max = M_max,
    lambda_q = lambda_schedule(epoch),
    max_grad_norm = 1.0,
    scheduler_step = scheduler_step
  )
  if(tr$ce < ce_mem){
    message("Saving hrm date: ",format(Sys.time(),"%d/%m/%y %H:%M:%S"))
    torch_save(model$state_dict(),"hrm.ptx")
    ce_mem <- tr$ce
  }
  cat(sprintf("epoch %02d/%02d | loss=%.4f | ce=%.4f | actq=%.4f\n",epoch, epochs, tr$loss, tr$ce, tr$actq))
}

# save memoria trei
if (tr$ce < ce_mem) {
  message("Saving training state: ", format(Sys.time(), "%d/%m/%y %H:%M:%S"))
  checkpoint <- list(
    model_state = model$state_dict(),
    optimizer_state = optimizer$state_dict(),
    step_counter = step_counter,
    ce_mem = tr$ce,
    epoch = epoch
  )
  torch_save(checkpoint, "checkpoint.ptx")
  ce_mem <- tr$ce
}

#Teste
print_target_pred(model,dl = train_dl, tokenizer, n = 100, M_max = M_max,device = device, halt_margin = 0.05,show_prompt = TRUE,loop_max = 10)


# state_dict <- torch_load("hrm.ptx")
# model$load_state_dict(state_dict)

model$eval()
train$test = FALSE
#288
x <- str_count(train$df$obj,"pessoa")
indexs  <- as.logical(ifelse(is.na(str_count(x)),0,x > 0)) #which(train$df$collision)

index   <- sample(1:train$.length(),1)

b       <- train$.getitem(index)
prompt  <- torch_cat(list(b$prompt,rep(tokenizer$get_pad_token_id(),tokenizer$get_max_len() - b$prompt$size()[1])),1L)$unsqueeze(1)$to(device = device)
target  <- torch_cat(list(b$target_token,rep(tokenizer$get_pad_token_id(),tokenizer$get_max_len() - b$target_token$size()[1])),1L)$unsqueeze(1)$to(device = device)
img     <- b$images$unsqueeze(1)$to(device = device)

# pr <- hrm_predict(model,
#                   prompt_ids = prompt$to(device = device),
#                   image = img$to(device = device),
#                   M_max = M_max, device = device,
#                   halt_margin = 0.0)

pred_ids  <- model$forward(prompt_ids = prompt$to(device = device),
                       image = img$to(device = device),
                       M_max = torch_tensor(4L)$to(device = device),
                       halt_margin = torch_tensor(0.05)$to(device = device))


obj   <- safe_json(tokenizer$dencoder(pred_ids,stop_end = TRUE))
y     <- tokenizer$dencoder(target,stop_end = TRUE)

# image
img_out <- image_read(as_array(img[1,3,,,]$permute(c(2,3,1))$cpu()))


print(tokenizer$dencoder(prompt))
print(y)
print(tokenizer$dencoder(pred_ids,stop_end = TRUE))
img_out

