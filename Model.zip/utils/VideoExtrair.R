
# install.packages(c("av","imager","future","future.apply"))
require(av)
require(imager)
require(future)
require(future.apply)
library(tidyverse)

extract_frames_trim_resize <- function(
  video,
  from, to,                 # segundos OU "HH:MM:SS"
  fps,
  outdir,
  width = NULL, height = NULL,
  format = c("jpg","jpeg","png"),
  num_workers = max(1L, parallel::detectCores(logical = TRUE) - 1L)
) {
 # format <- match.arg(tolower(format))

  # ---- helpers ----
  to_seconds <- function(x) {
    if (is.numeric(x)) return(as.numeric(x))
    stopifnot(is.character(x), length(x) == 1)
    parts <- as.integer(strsplit(x, ":", fixed = TRUE)[[1]])
    if (length(parts) == 3) return(parts[1]*3600 + parts[2]*60 + parts[3])
    if (length(parts) == 2) return(parts[1]*60 + parts[2])
    as.numeric(x)
  }

  start <- to_seconds(from)
  end   <- to_seconds(to)
  stopifnot(end > start)

  # ---- logs ----
  msg <- function(...) cat(sprintf("[%s] ", format(Sys.time(), "%H:%M:%S")), sprintf(...), "\n")
  msg("Vídeo: %s", video)
  msg("Janela: start=%0.3fs  end=%0.3fs  (semântica [start, end))", start, end)
  msg("FPS de saída: %s", fps)
  if (!is.null(width) && !is.null(height)) {
    msg("Resize habilitado: %dx%d", width, height)
  } else {
    msg("Resize desabilitado (width/height não informados).")
  }

  # ---- extração de frames ----
  dir.create(outdir, showWarnings = FALSE, recursive = TRUE)
  msg("Extraindo frames → %s ...", outdir)
  trim_str <- paste0(start, ":", end)  # ffmpeg trim: start inclusive, end exclusivo

  tryCatch({
    av::av_video_images(
      video   = video,
      destdir = outdir,
      format  = format,
      fps     = fps,
      trim    = trim_str
    )
  }, error = function(e) {
    stop(sprintf("Falha em av_video_images(): %s", conditionMessage(e)))
  })

  # detectar arquivos gerados (cubra .jpg/.jpeg/.png)
  patt <- paste0("\\.", format, "$")
  imgs <- list.files(outdir, pattern = patt, full.names = TRUE)
  if (length(imgs) == 0 && format == "jpg") {
    # fallback para ".jpeg" se o encoder usar essa extensão
    imgs <- list.files(outdir, pattern = "\\.jpeg$", full.names = TRUE)
  }
  msg("Frames extraídos: %d arquivo(s).", length(imgs))

  # ---- resize em paralelo (opcional) ----
  if (!is.null(width) && !is.null(height) && length(imgs) > 0) {
    msg("Iniciando resize em paralelo (%d workers)...", num_workers)
    old_plan <- future::plan()
    on.exit(future::plan(old_plan), add = TRUE)

    future::plan(future::multisession, workers = num_workers)
    # logs leves por lote
    n <- length(imgs)
    chunk <- max(1L, n %/% (num_workers * 4L))

    future.apply::future_lapply(seq_along(imgs), function(i) {
      img_path <- imgs[[i]]
      im  <- imager::load.image(img_path)
      imr <- imager::resize(im, width, height)
      imager::save.image(imr, img_path)
      if ((i %% chunk) == 0L) {
        cat(sprintf("[resize] %d/%d\r", i, n))
        flush.console()
      }
      NULL
    })
    cat("\n")
    msg("Resize concluído.")
  }

  msg("Processo finalizado.")
  invisible(imgs)
}

df <- tibble(
       video = c("video/1.mp4","video/1.mp4","video/1.mp4","video/2.mp4"),
       dir   = c("0","1","2","3"),
       from  = c("00:00:00","00:07:40","00:20:00","00:09:00"),
       to    = c("00:01:00","00:08:40","00:21:00","00:10:00"),
       target = list(list(maquina = "Corte-Prensa",estado = "stop",bobina = "on"),
                     list(maquina = "Corte-Prensa",estado = "stop",bobina = "off"),
                     list(maquina = "Corte-Prensa",estado = "stop",bobina = "on"),
                     list(maquina = "Corte-Prensa",estado = "operation",bobina = "on"))
       )
dir_path <- "frames"
total    <- nrow(df)
for(i in 1:total){

  message("################### Loop Processo in: ",round((i / total) * 100.0,2),"% ###################")
  
  #file.remove(list.files(paste0(dir_path,"/",df$dir[i]),full.names = T))
  if(!dir.exists(paste0(dir_path,"/",df$dir[i]))) dir.create(paste0(dir_path,"/",df$dir[i]))

  extract_frames_trim_resize(
    video = df$video[i],
    from = df$from[i],
    to   = df$to[i],
    fps  = 1,
    outdir = paste0(dir_path,"/",df$dir[i]),
    width = 512, height = 512,   # ou NULL,NULL para não redimensionar
    format = "png",
    num_workers = 8
  )
  descricao <- df$target[[i]]

  jsonlite::write_json(descricao,paste0(paste0(dir_path,"/",df$dir[i]),"/info.json"),auto_unbox = T)
}

