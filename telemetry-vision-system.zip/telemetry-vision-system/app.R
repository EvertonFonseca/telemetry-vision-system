# Rhino / shinyApp entrypoint. Do not edit.
rhino::app()

# options(shiny.maxRequestSize = 2048 * 1024^2)
install.packages("shinyBS")
# # app.R
# library(shiny)
# library(leaflet)
# library(leaflet.extras)
# library(magick)
# library(jsonlite)
# library(base64enc)
# library(DBI)

# ui <- fluidPage(
#   tags$head(tags$style(HTML("
#     #map { border: 1px solid #ccc; }
#     .disabled { pointer-events: none; opacity: 0.6; }
#   "))),
#   titlePanel("Shiny: Desenhar polígono e recortar imagem"),
#   sidebarLayout(
#     sidebarPanel(
#       fileInput("img_file", "Carregar imagem (PNG/JPG)", accept = c(".png", ".jpg", ".jpeg")),
#       actionButton("clear", "Limpar polígonos"),
#       br(), br(),
#       actionButton("save_poly", "Salvar/Recortar Polígono", class = "btn-primary"),
#       br(), br(),
#       downloadButton("dl_cropped", "Baixar recorte (PNG)"),
#       br(), br(),
#       verbatimTextOutput("info")
#     ),
#     mainPanel(
#       # O leaflet vai se ajustar ao tamanho da imagem; atualizo via renderLeaflet
#       leafletOutput("map", height = "600px")
#     )
#   )
# )

# server <- function(input, output, session) {

#   con <- DBI::dbConnect(
#     drv      = RMariaDB::MariaDB(),
#     dbname   = "system",
#     host     = "127.0.0.1",
#     user     = "root",
#     password = "ssbwarcq",
#     bigint   = "integer"
#   )

#   rv <- reactiveValues(
#     img = NULL,          # objeto magick
#     img_path = NULL,     # caminho temp do PNG para overlay
#     w = NULL, h = NULL,  # dimensões em px
#     poly = NULL,         # data.frame x,y do polígono em coords de imagem
#     cropped_path = NULL  # caminho do recorte PNG
#   )

#   dados <- dbGetQuery(con, "SELECT CD_ID_FRAME, CD_ID_CAMERA,DATA_FRAME , DT_HR_LOCAL
#                             FROM FRAME_CAMERA ORDER BY CD_ID_FRAME")

#   # Carrega imagem
#  # observeEvent(input$img_file, {
#  #   req(input$img_file$datapath)
#     img  <- image_read(dados$DATA_FRAME[[1]])
#     info <- image_info(img)
#     rv$img <- img
#     rv$w <- info$width
#     rv$h <- info$height

#     # Gera um PNG em temp e um dataURI (para overlay no Leaflet)
#     tmp_png <- tempfile(fileext = ".png")
#     image_write(img, path = tmp_png, format = "png")
#     rv$img_path <- tmp_png

#     output$map <- renderLeaflet({
#       req(rv$w, rv$h, rv$img_path)
#       data_uri <- dataURI(file = rv$img_path, mime = "image/png")

#       leaflet(options = leafletOptions(crs = leafletCRS(crsClass = "L.CRS.Simple"))) |>
#       addDrawToolbar(
#         targetGroup = "draw",
#         polylineOptions      = FALSE,
#         circleMarkerOptions  = FALSE,
#         markerOptions        = FALSE,

#         # HABILITA polígono
#         polygonOptions = drawPolygonOptions(
#           shapeOptions = drawShapeOptions(fillOpacity = 0.2, weight = 2)
#         ),

#         # HABILITA retângulo
#         rectangleOptions = drawRectangleOptions(
#           shapeOptions = drawShapeOptions(fillOpacity = 0.2, weight = 2)
#         ),

#         # HABILITA círculo
#         circleOptions = drawCircleOptions(
#           shapeOptions = drawShapeOptions(fillOpacity = 0.2, weight = 2)
#         ),

#         editOptions = editToolbarOptions(
#           selectedPathOptions = selectedPathOptions()
#         )
#       ) |>
#       htmlwidgets::onRender(
#         "
#         function(el, x, data){
#           var map = this;
#           var bounds = [[0,0], [data.h, data.w]];
#           L.imageOverlay(data.imageUrl, bounds, {opacity: 1}).addTo(map);
#           map.fitBounds(bounds);
#           map.setMaxBounds(bounds);
#         }
#         ",
#         data = list(imageUrl = data_uri, w = rv$w, h = rv$h)
#       )
#     })

#     rv$poly <- NULL
#     rv$cropped_path <- NULL
#  # })

#   # Captura novo polígono desenhado
#   observeEvent(input$map_draw_new_feature, {
#     feat <- input$map_draw_new_feature
#     if (is.null(feat)) return()
#     if (!identical(feat$geometry$type, "Polygon")) return()

#     # GeoJSON coords: list(list(c(lng,lat), ...))
#     coords <- feat$geometry$coordinates[[1]]
#     lng <- vapply(coords, function(x) x[[1]], numeric(1))
#     lat <- vapply(coords, function(x) x[[2]], numeric(1))
#     poly <- data.frame(x = lng, y = lat)

#     # Remove possível ponto duplicado final (= inicial)
#     if (nrow(poly) >= 2 && isTRUE(all(poly[1, ] == poly[nrow(poly), ]))) {
#       poly <- poly[-nrow(poly), ]
#     }

#     # Mantém só 1 polígono atual (último desenhado)
#     rv$poly <- poly
#   })

#   # Captura edições (mover vértices, etc.)
#   observeEvent(input$map_draw_edited_features, {
#     feats <- input$map_draw_edited_features
#     if (is.null(feats$features) || length(feats$features) == 0) return()
#     feat <- feats$features[[1]]
#     if (!identical(feat$geometry$type, "Polygon")) return()
#     coords <- feat$geometry$coordinates[[1]]
#     lng <- vapply(coords, function(x) x[[1]], numeric(1))
#     lat <- vapply(coords, function(x) x[[2]], numeric(1))
#     poly <- data.frame(x = lng, y = lat)
#     if (nrow(poly) >= 2 && isTRUE(all(poly[1, ] == poly[nrow(poly), ]))) {
#       poly <- poly[-nrow(poly), ]
#     }
#     rv$poly <- poly
#   })

#   # Limpa desenhos
#   observeEvent(input$clear, {
#     leafletProxy("map") |> clearGroup("draw")
#     rv$poly <- NULL
#     rv$cropped_path <- NULL
#   })

#   # Recorta dentro do polígono
#   observeEvent(input$save_poly, {
#     req(rv$img, rv$w, rv$h, rv$poly)

#       poly <- rv$poly

#       # IMPORTANTE: Em magick::image_draw, o eixo Y cresce para cima (como plot base).
#       # Já no Leaflet CRS.Simple, y (lat) cresce para baixo (pixels).
#       # Por isso, precisamos espelhar Y: y_plot = h - y_leaflet
#       y_plot <- rv$h - poly$y
#       x_plot <- poly$x

#       # 1) Cria uma máscara RGBA: polígono branco sobre fundo preto
#       mask <- image_blank(rv$w, rv$h, color = "black")
#       imgd <- image_draw(mask)
#       polygon(x_plot, y_plot, col = "white", border = NA)
#       dev.off()

#      image_write(imgd,"poligno.jpeg")
#   })

#   # Download do recorte
#   output$dl_cropped <- downloadHandler(
#     filename = function() {
#       paste0("recorte_poligono_", format(Sys.time(), "%Y%m%d-%H%M%S"), ".png")
#     },
#     content = function(file) {
#       req(rv$cropped_path)
#       file.copy(rv$cropped_path, file, overwrite = TRUE)
#     }
#   )

#   # Info rápida
#   output$info <- renderPrint({
#     list(
#       img_dim = if (!is.null(rv$w)) c(width = rv$w, height = rv$h) else NULL,
#       has_poly = !is.null(rv$poly),
#       poly_head = if (!is.null(rv$poly)) head(rv$poly) else NULL,
#       cropped_ready = !is.null(rv$cropped_path)
#     )
#   })
# }

# shinyApp(ui, server)
