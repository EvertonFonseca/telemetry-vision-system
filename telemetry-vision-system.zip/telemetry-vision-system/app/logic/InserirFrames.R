source("app/logic/utils.R")
source("app/logic/database.R")

# util tx
.run_tx_bool <- function(con, expr) {
  DBI::dbBegin(con); ok <- FALSE
  on.exit(if (!ok) DBI::dbRollback(con), add = TRUE)
  out <- try(expr, silent = TRUE); if (inherits(out, "try-error")) return(FALSE)
  DBI::dbCommit(con); ok <- TRUE; TRUE
}

# Lê arquivo como raw
.read_raw <- function(p) {
  if (!file.exists(p)) stop("Arquivo não existe: ", p)
  sz <- file.info(p)$size; if (is.na(sz) || sz <= 0) stop("Arquivo vazio: ", p)
  f <- file(p, "rb"); on.exit(close(f), add = TRUE); readBin(f, "raw", n = sz)
}

# Insere DATA_FRAME e CD_ID_CAMERA; DT_HR_LOCAL usa DEFAULT CURRENT_TIMESTAMP
insertFramesFromPaths <- function(con, camera_id, paths) {
  stopifnot(length(camera_id) == 1L, length(paths) >= 1L)
  sql <- 'INSERT INTO FRAME_CAMERA (DATA_FRAME, CD_ID_CAMERA) VALUES (?, ?)'
  .run_tx_bool(con, {
    for (p in paths) {
      blob_raw <- .read_raw(p)
      n <- DBI::dbExecute(con, sql, params = list(blob_raw, as.integer(camera_id)))
      if (!is.na(n) && n < 1L) stop("INSERT não afetou linha: ", p)
    }
    invisible(TRUE)
  })
}

library(DBI)
library(RMariaDB)
library(gtools)

con <- newConnection()

paths <- mixedsort(list.files(
        "C:/Sistema/Everton/VisionTelemetrycSystem/frames/0",full.names = T,
        pattern = "image_"
      ))

ok <- insertFramesFromPaths(con, camera_id = 1, paths = paths)
if (ok) {
  message("Tudo inserido com sucesso!")
} else {
  message("Falhou e foi feito rollback.")
}

dbDisconnect(con)


library(DBI)
library(blob)
library(purrr)

insert_batch <- function(con, paths, camera_id) {
  df <- data.frame(
    DATA_FRAME   = I(map(paths, ~ blob::blob(.read_raw(.x)))),
    CD_ID_CAMERA = camera_id,
    stringsAsFactors = FALSE
  )

  stmt <- DBI::dbSendStatement(con, 'INSERT INTO FRAME_CAMERA (DATA_FRAME, CD_ID_CAMERA) VALUES (?, ?)')
  on.exit(try(DBI::dbClearResult(stmt), silent = TRUE), add = TRUE)
  DBI::dbBind(stmt, df)  # <- bind vetorizado corretamente (mesmo nº de linhas/colunas)
  DBI::dbGetRowsAffected(stmt)
}
insert_batch(con,paths,1)

I(blob::blob(.read_raw("C:/Sistema/Everton/VisionTelemetrycSystem/frames/0/image_000060.png")))

I(map(paths, ~ blob::blob(.read_raw(.x))))



# 1) gera um PNG temporário simples (10x10) só para exemplo
png_path <- tempfile(fileext = ".png")
png(filename = png_path, width = 10, height = 10)
par(mar = c(0,0,0,0))
plot.new(); rect(0,0,1,1, col="#00AAFF", border=NA)  # quadrado azul
dev.off()

# 2) lê como raw (BLOB)
read_raw <- function(path) {
  f <- file(path, "rb"); on.exit(close(f), add = TRUE)
  readBin(f, what="raw", n=file.info(path)$size)
}

png_path <- "C:/Sistema/Everton/VisionTelemetrycSystem/frames/0/image_000060.png"
raw_png <- read_raw(png_path)

# 3) insere (DT_HR_LOCAL usa DEFAULT do banco)
sql <- 'INSERT INTO FRAME_CAMERA (DATA_FRAME, CD_ID_CAMERA) VALUES (?, ?)'
n <- dbExecute(con, sql, params = list(blob::blob(raw_png), 1L))  # 42 = exemplo de câmera
print(n)  # linhas afetadas

# verificação (não puxe o LONGBLOB completo)
dados <- dbGetQuery(con, "SELECT CD_ID_FRAME, CD_ID_CAMERA,DATA_FRAME , DT_HR_LOCAL
                 FROM FRAME_CAMERA ORDER BY CD_ID_FRAME")

magick::image_read(dados$DATA_FRAME[[1]])
