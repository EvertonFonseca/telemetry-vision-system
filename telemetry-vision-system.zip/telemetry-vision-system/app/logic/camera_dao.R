box::use(DBI,dplyr[pull],./utils[...])

#' @export
checkifExistNameCamera <- function(con,name){
  
  DBI$dbGetQuery(con,'SELECT COUNT(*) AS STATUS FROM CAMERA_VIEW WHERE NAME_CAMERA = ?',params = list(name)) |>  pull() > 0
  
} 
#' @export
checkifExistNameCameraEdit <- function(con,id,name){
  
  DBI$dbGetQuery(con,'SELECT COUNT(*) AS STATUS FROM CAMERA_VIEW WHERE NAME_CAMERA = ? AND CD_ID_CAMERA != ?',params = list(name,id)) |>  pull() > 0
  
}
#' @export
checkifExistUrlCamera <- function(con,url){
  
  DBI$dbGetQuery(con,'SELECT COUNT(*) AS STATUS FROM CAMERA_VIEW WHERE URL_CAMERA = ?',params = list(url)) |>  pull() > 0
  
}

#' @export
checkifExistUrlCameraEdit <- function(con,id,url){
  
  DBI$dbGetQuery(con,'SELECT COUNT(*) AS STATUS FROM CAMERA_VIEW WHERE URL_CAMERA = ? AND CD_ID_CAMERA != ?',params = list(url,id)) |>  pull() > 0
  
}
#' @export
selectAllFrame <- function(con){

   DBI$dbGetQuery(con, "SELECT CD_ID_FRAME, CD_ID_CAMERA,DATA_FRAME , DT_HR_LOCAL
                        FROM FRAME_CAMERA ORDER BY CD_ID_FRAME")
}

#' @export
insertNewCamera <- function(con, id, camera) {
  
  stopifnot(!is.null(id), !is.null(camera$NAME_CAMERA), !is.null(camera$URL_CAMERA), !is.null(camera$FPS_CAMERA))

  .run_tx_bool(con, {
    n1 <- DBI::dbExecute(
      con,
      'INSERT INTO CAMERA_VIEW (CD_ID_CAMERA, NAME_CAMERA, URL_CAMERA) VALUES (?, ?, ?)',
      params = list(
        as.integer(id),
        camera$NAME_CAMERA,
        camera$URL_CAMERA
      )
    )

    n2 <- DBI::dbExecute(
      con,
      'INSERT INTO CAMERA_CONFIG (CD_ID_CAMERA, FPS_CAMERA) VALUES (?, ?)',
      params = list(
        as.integer(id),
        camera$FPS_CAMERA
      )
    )

    # Falha lógica se nenhum statement afetou linhas (casos raros, mas checamos)
    if (!.affected_ok(n1) || !.affected_ok(n2)) stop("INSERT não afetou linhas.")
    invisible(TRUE)
  })
}

#' @export
updateCamera <- function(con, camera) {

  stopifnot(!is.null(camera$CD_ID_CAMERA))

  .run_tx_bool(con, {
    n1 <- DBI::dbExecute(
      con,
      'UPDATE CAMERA_VIEW
         SET NAME_CAMERA = ?,
             URL_CAMERA  = ?
       WHERE CD_ID_CAMERA = ?',
      params = list(
        camera$NAME_CAMERA,
        camera$URL_CAMERA,
        as.integer(camera$CD_ID_CAMERA)
      )
    )

    n2 <- DBI::dbExecute(
      con,
      'UPDATE CAMERA_CONFIG
          SET FPS_CAMERA = ?
        WHERE CD_ID_CAMERA = ?',
      params = list(
        camera$FPS_CAMERA,
        as.integer(camera$CD_ID_CAMERA)
      )
    )

    # Se nenhuma tabela foi afetada, consideramos falha lógica
    if (!.affected_ok(n1) && !.affected_ok(n2)) stop("UPDATE não afetou linhas.")
    invisible(TRUE)
  })
}

# Continua retornando um data.frame (consulta)
#' @export
selectAllCameras <- function(con) {
  sql <- '
    SELECT
      cv.CD_ID_CAMERA,
      cv.NAME_CAMERA,
      cv.URL_CAMERA,
      cc.FPS_CAMERA,
      cc.DT_HR_LOCAL
    FROM CAMERA_VIEW cv
    LEFT JOIN (
      SELECT c1.CD_ID_CAMERA, c1.FPS_CAMERA, c1.DT_HR_LOCAL
      FROM CAMERA_CONFIG c1
      JOIN (
        SELECT CD_ID_CAMERA, MAX(DT_HR_LOCAL) AS max_dt
        FROM CAMERA_CONFIG
        GROUP BY CD_ID_CAMERA
      ) latest
        ON latest.CD_ID_CAMERA = c1.CD_ID_CAMERA
       AND latest.max_dt      = c1.DT_HR_LOCAL
    ) cc ON cc.CD_ID_CAMERA = cv.CD_ID_CAMERA
    ORDER BY cv.CD_ID_CAMERA
  '
  DBI::dbGetQuery(con, sql)
}

#' @export
deleteCamera <- function(con, id) {
  stopifnot(!is.null(id))
  .run_tx_bool(con, {
    # Apaga configs primeiro (se houver FK)
    n1 <- DBI::dbExecute(con, 'DELETE FROM CAMERA_VIEW   WHERE CD_ID_CAMERA = ?', params = list(as.integer(id)))
    # Se nada foi apagado na VIEW principal, tratamos como falha lógica
    if (!.affected_ok(n1)) stop("DELETE não encontrou a câmera informada.")
    invisible(TRUE)
  })
}
