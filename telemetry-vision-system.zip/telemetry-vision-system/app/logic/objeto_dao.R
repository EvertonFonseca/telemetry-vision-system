box::use(DBI,dplyr[pull])

#' @export
checkifExistNameObjeto <- function(con,name){
  
  DBI$dbGetQuery(con,'SELECT COUNT(*) AS STATUS FROM OBJETO WHERE NAME_OBJETO = ?',params = list(name)) |>  pull() > 0
  
} 
#' @export
checkifExistNameObjetoEdit <- function(con,id,name){
  
  DBI$dbGetQuery(con,'SELECT COUNT(*) AS STATUS FROM OBJETO WHERE NAME_OBJETO = ? AND CD_ID_OBJETO != ?',params = list(name,id)) |>  pull() > 0
  
}
#' @export
checkifExistUrlObjeto <- function(con,url){
  
  DBI$dbGetQuery(con,'SELECT COUNT(*) AS STATUS FROM OBJETO WHERE URL_OBJETO = ?',params = list(url)) |>  pull() > 0
  
}

#' @export
checkifExistUrlObjetoEdit <- function(con,id,url){
  
  DBI$dbGetQuery(con,'SELECT COUNT(*) AS STATUS FROM OBJETO WHERE URL_OBJETO = ? AND CD_ID_OBJETO != ?',params = list(url,id)) |>  pull() > 0
  
}

#' @export
insertNewObjeto <- function(con,id,camera){
  
  tryCatch({
    query <- 'INSERT INTO OBJETO (CD_ID_OBJETO,NAME_OBJETO,URL_OBJETO,FPS_OBJETO) VALUES (?,?,?,?)'
    result <-  DBI$dbSendStatement(con,query)
    DBI$dbBind(result, c(
      as.integer(id),
      camera$NAME_OBJETO,
      camera$URL_OBJETO,
      camera$FPS_OBJETO
    ))
    DBI$dbClearResult(result)
    
  })
  
  return(as.integer(id))
}
#' @export
updateObjeto <- function(con,camera){
  
  tryCatch({
    
    query <- 'UPDATE OBJETO SET NAME_OBJETO = ?,
                              URL_OBJETO = ?,
                              FPS_OBJETO = ?
                              WHERE CD_ID_OBJETO = ?'
    result <-  DBI$dbSendStatement(con,query)
    DBI$dbBind(result,c(
      camera$NAME_OBJETO,
      camera$URL_OBJETO,
      camera$FPS_OBJETO,
      camera$CD_ID_OBJETO
    ))
    DBI$dbClearResult(result)
  })
}
#' @export
selectAllObjetos <- function(con){
  DBI$dbGetQuery(con,'SELECT * FROM OBJETO')
}

#' @export
selectAllTipoDados <- function(con){
  DBI$dbGetQuery(con,'SELECT * FROM TIPO_DATA')
}

#' @export
deleteObjeto <- function(con,id){
  DBI::dbExecute(con,paste0('DELETE FROM OBJETO WHERE CD_ID_OBJETO = ',id))
}