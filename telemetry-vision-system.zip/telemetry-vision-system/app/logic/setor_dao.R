box::use(DBI,dplyr[pull])

#' @export
checkifExistNameSetor <- function(con,name){
  
  DBI$dbGetQuery(con,'SELECT COUNT(*) AS STATUS FROM OJETO WHERE NAME_CAMERA = ?',params = list(name)) |>  pull() > 0
  
} 
#' @export
checkifExistNameSetorEdit <- function(con,id,name){
  
  DBI$dbGetQuery(con,'SELECT COUNT(*) AS STATUS FROM OJETO WHERE NAME_CAMERA = ? AND CD_ID_CAMERA != ?',params = list(name,id)) |>  pull() > 0
  
}
#' @export
checkifExistUrlSetor <- function(con,url){
  
  DBI$dbGetQuery(con,'SELECT COUNT(*) AS STATUS FROM OJETO WHERE URL_CAMERA = ?',params = list(url)) |>  pull() > 0
  
}

#' @export
checkifExistUrlSetorEdit <- function(con,id,url){
  
  DBI$dbGetQuery(con,'SELECT COUNT(*) AS STATUS FROM OJETO WHERE URL_CAMERA = ? AND CD_ID_CAMERA != ?',params = list(url,id)) |>  pull() > 0
  
}

#' @export
insertNewSetor <- function(con,id,camera){
  
  tryCatch({
    query <- 'INSERT INTO OJETO (CD_ID_CAMERA,NAME_CAMERA,URL_CAMERA,FPS_CAMERA) VALUES (?,?,?,?)'
    result <-  DBI$dbSendStatement(con,query)
    DBI$dbBind(result, c(
      as.integer(id),
      camera$NAME_CAMERA,
      camera$URL_CAMERA,
      camera$FPS_CAMERA
    ))
    DBI$dbClearResult(result)
    
  })
  
  return(as.integer(id))
}
#' @export
updateSetor <- function(con,camera){
  
  tryCatch({
    
    query <- 'UPDATE OJETO SET NAME_CAMERA = ?,
                              URL_CAMERA = ?,
                              FPS_CAMERA = ?
                              WHERE CD_ID_CAMERA = ?'
    result <-  DBI$dbSendStatement(con,query)
    DBI$dbBind(result,c(
      camera$NAME_CAMERA,
      camera$URL_CAMERA,
      camera$FPS_CAMERA,
      camera$CD_ID_CAMERA
    ))
    DBI$dbClearResult(result)
  })
}
#' @export
selectAllSetors <- function(con){
  
  DBI$dbGetQuery(con,'SELECT * FROM OJETO')

}

#' @export
deleteSetor <- function(con,id){
  DBI::dbExecute(con,paste0('DELETE FROM OJETO WHERE CD_ID_CAMERA = ',id))
}