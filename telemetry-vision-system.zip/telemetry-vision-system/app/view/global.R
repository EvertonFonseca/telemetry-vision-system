box::use(
 shiny[div,splitLayout,tags,absolutePanel,removeModal,insertUI,br,actionButton,observeEvent],
 shinydashboard[menuSubItem],
 stringi[stri_isempty],
 shinyjs[onclick,runjs,delay],
 vov,
 R6
)

#' Coleção de observers com ciclo de vida controlado
#'
#' Mantém uma lista de objetos retornados por observe/observeEvent, permitindo
#' adicionar, remover, limpar e destruir (chamar $destroy() em todos).
#'
#' Métodos:
#'  - $add(o)         : adiciona um observer (ignora NULL)
#'  - $clear()        : destroy() em todos e esvazia a lista
#'  - $remove(obs)    : remove por referência (identical) ou por índice numérico
#'  - $destroy()      : alias para $clear(); usado para desalocar
#'  - $items (active) : acesso somente-leitura à lista interna
#'

#' @export
ObserversBag <- R6$R6Class(
  "ObserversBag",
  public = list(
    initialize = function() {
      private$listobserves <- list()
    },

    add = function(o) {
      if (!is.null(o)) private$listobserves <- append(private$listobserves, list(o))
      invisible(self)
    },

    clear = function() {
      lapply(private$listobserves, function(x) try(x$destroy(), silent = TRUE))
      private$listobserves <- list()
      invisible(self)
    },

    remove = function(o) {
      idx <- integer()
      if (is.numeric(o)) {
        idx <- intersect(as.integer(o), seq_along(private$listobserves))
      } else {
        idx <- which(vapply(private$listobserves, function(x) identical(x, o), logical(1)))
      }
      if (length(idx)) {
        lapply(idx, function(i) try(private$listobserves[[i]]$destroy(), silent = TRUE))
        private$listobserves <- private$listobserves[-idx]
      }
      invisible(self)
    },

    destroy = function() {
      self$clear()
      invisible(NULL)
    }
  ),

  private = list(
    listobserves = list(),

    # finalize agora é PRIVATE (requisito do R6 >= 2.4.0)
    finalize = function() {
      lapply(private$listobserves, function(x) try(x$destroy(), silent = TRUE))
    }
  )
)

# Factory preservando a sua assinatura atual
#' @export
newObserve <- function() ObserversBag$new()

#' @export
MenuSubItem  <- function(id = NULL,
                         text,
                         tabName = NULL,
                         href = NULL,
                         newtab = TRUE,
                         icon = shiny::icon("angle-double-right"),
                         selected = NULL,
                         hide = FALSE) {
  
  styleinline <- 'margin-left: 8px; padding: 5px; height: 35px;'
  styleinline <- if(hide) paste0(styleinline," display:none !important;")
  component     <- div(
    id = id,
    style = styleinline,
    splitLayout(
      cellWidths = 'auto',
      tags$span(icon),
      div(style = 'margin-left: 5px;',
          menuSubItem(
            text,
            tabName = tabName,
            href = href,
            newtab = newtab,
            icon = NULL,
            selected = selected
          )
      )
    )
  )
  return(component)
}

#' @export
panelTitle <- function(id = '',
                       display = 'block',
                       title = '',
                       width = 'auto',
                       height = 'auto',
                       id.tooltip = '',
                       title.tooltip = '',
                       title.color   = 'gray',
                       background.color.title = 'white',
                       border.color = 'gray',
                       children) {
  
  if(!stri_isempty(id.tooltip))
    tooltipComponent <- div(
      id = id.tooltip,
      style = 'float: left; margin-left: 5px',
      icon('info-circle'),
      bsTooltip(
        id.tooltip,
        title.tooltip,
        "right",
        options = list(container = "body")
      )
    )
  else
    tooltipComponent <- NULL
  
  return(
    div(id = id,
        style = paste0('position: relative; ', 'display: ', display, '; height: ',height,'; width: ',width,';','border-color: ',border.color,'; border-style: solid; border-width: 1px;'),
        div(class = 'panelTitle',
            div(tags$span(style = 'float: left;',paste0(" ",title," ")),tooltipComponent,
                style = paste0(' position: absolute; top:-10px; left: 10px; background-color: ',background.color.title,'; color: ',title.color,';')),
            div(style = 'margin-top: 5px;',children))))
}

#' @export
dialogTitleClose <- function(id,title,active.bt.close = TRUE){
  
  btcloser <- NULL
  
  if(active.bt.close)
    btcloser <- absolutePanel(id = id,right = 15,top = 10,'x',style = 'cursor: pointer; font-weight: bold;')
  
  container <- div(title,btcloser)
  return(container)
}

#' @export
removeModalClear <- function(session){
  removeModal(session)
  runjs('$(".modal-body").html("");')
}

#' @export
shinySetInputValue <- function(id,value = NULL){

  value <- ifelse(is.null(value),'null',value)
  value <- ifelse(stringi::stri_isempty(value),"''",value)
  
  if(is.vector(id))
  {
   js <- sapply(id, function(x)  paste0("Shiny.setInputValue('",x,"',",value,",{priority:'event'});"))
   shinyjs::runjs(paste0(js,collapse = '\n '))
    
  }else{
    shinyjs::runjs(paste0("Shiny.setInputValue('",id,"',",value,",{priority:'event'});"))
  }
}

#' @export
play_sound <- function(session,id_local) {
  session$sendCustomMessage("play-audio", list(id = id_local))
}

#' @export
debugLocal <- function(expr) {
  
   debug(expr)
   x <- expr()
   undebug(expr)
   return(x)
}

#' @export
console <- function(text){
  shinyjs::runjs(paste0("console.log('",text,"');"))
}

#Cria um dialog dinamico
#' @export
messageAlerta <- function(input,ns,title = 'Mensagem de Alerta!',message,callback.yes,callback.no) {
  
  obs <- newObserve()

  insertUI(
    selector = "#root",
    ui = div(
      id    = 'notificationWarning',
      style = "position: fixed; top: 0; left: 0; bottom: 0; right: 0; background-color: rgba(45,55,65,0.6); z-index: 999999; color: black; font-size: 15px;",
      vov$slide_in_right(absolutePanel(
        top = 25,
        right = 25,
        class = 'dialogChip',
        width = 300,
        div(
          style = 'padding: 15px',
          div(
            style = 'padding: 5px; border-style : solid; border-color: gray; border-width: 1px; border-top: none;  border-left: none;  border-right: none;',
            title
          ),
          br(),
          div(message),
          br(),
          div(
            style = 'padding: 5px; border-style : solid; border-color: gray; border-width: 1px; border-bottom: none;  border-left: none;  border-right: none;',
            div(
              style = 'float: right; padding-bottom: 5px;',
              actionButton(ns('btYesnotification'),'Sim'),
              actionButton(ns('btNonotification'),'Não')
            )
          )
        )
      ),duration = 'faster')
    )
  )

  obs$add(observeEvent(input$btYesnotification,{

    runjs("document.getElementById('notificationWarning').remove();")
    obs$destroy()
    callback.yes()
    
  },ignoreInit = TRUE))
  
  obs$add(observeEvent(input$btNonotification,{

    runjs("document.getElementById('notificationWarning').remove();")
    obs$destroy()
    callback.no()

  },ignoreInit = TRUE))

}
# Change Text's multiInput
#' @export
changetextPlaceHolder <- function(text = "Filtro ..."){
  
  delay(100,{
    runjs(paste0('
                  let lista = document.getElementsByClassName("search-input");\n
                  for(i = 0; i < lista.length; i++){ lista[i].placeholder = "',text,'"; }
                '))
  })
}

#' @export
tagAppendChildFind <- function(tag,target,child){
  
  tag$children[[target]]$children <- list.append(tag$children[[target]]$children,child)
  tag
}
#' @export
tagAppendAttributesFind <- function(tag,target,...){
  
  tag$children[[target]]$attribs <- c(tag$children[[target]]$attribs,...)
  tag
}
#' @export
tagAppendAttributesFindSub <- function(tag,target,...){
  
  if(length(target) == 2)
  {
    tag$children[[target[1]]]$children[[target[2]]]$attribs <- c(tag$children[[target[1]]]$children[[target[2]]]$attribs,...)
    tag
  }
  else if(length(target) == 3)
  {
    tag$children[[target[1]]]$children[[target[2]]]$children[[target[3]]]$attribs <- c(tag$children[[target[1]]]$children[[target[2]]]$children[[target[3]]]$attribs,...)
    tag
  }
}

#' @export
deleteElement <- function(id){
   runjs(paste0("document.getElementById('",id,"').remove();"))
}
