box::use(
  shinyjs[inlineCSS],
  shiny[...],
  stringi,
  . / model[...],
  . /
    global[
      deleteElement,
      dialogTitleClose,
      panelTitle,
      removeModalClear,
      newObserve,
      shinySetInputValue,
      play_sound,
      debugLocal,
      console,
      messageAlerta,
      changetextPlaceHolder,
      tagAppendAttributesFind
    ],
  .. / model / swiper[...],
  DT,
  shinycssloaders,
  db = .. / logic / database,
  .. / logic/objeto_dao[...],
  .. / logic/camera_dao[...],
  stringr,
  dplyr[...],
  lubridate[...],
  shinyWidgets[multiInput,updateMultiInput,prettyToggle],
  leaflet[...],
  leaflet.extras[...],
  magick[...],
  htmlwidgets,
  base64enc
)


#' @export
 uiNewObjeto <- function(ns,input,output,session){
   
  #open database
  con     <- db$newConnection()
  obs     <- newObserve()
  obs2    <- newObserve()
  cameras   <- reactiveVal(selectAllCameras(con))
  tipoDatas <- selectAllTipoDados(con)
  camerasSelected <- reactiveVal(NULL)

  sliderPosition <- reactiveVal(1L)
  idSwiper       <- ns('swiperMain')
  rv <- reactiveValues(
      img = NULL,          # objeto magick
      img_path = NULL,     # caminho temp do PNG para overlay
      w = NULL, h = NULL,  # dimensões em px
      poly = NULL,         # data.frame x,y do polígono em coords de imagem
      cropped_path = NULL  # caminho do recorte PNG
  )
  componenteReactive <- reactiveVal(NULL)

  showModal(
    session = session,
    dialogModal(
      title = textOutput(ns("titleTexto")),
      size = 'm',
      swiper(id = idSwiper,width = '100%',height = '580px',
            swiperSlide(
              style = 'height: 100%; width: 100%; overflow: hidden; padding: 5px;',
              uiOutput(ns('slider1')) |> shinycssloaders$withSpinner(color = 'lightblue')
            ),
            swiperSlide(
              style = 'height: 100%; width: 100%; overflow: hidden; padding: 5px;',
              uiOutput(ns('slider2')) |> shinycssloaders$withSpinner(color = 'lightblue')
            ),
            swiperSlide(
              style = 'height: 100%; width: 100%; overflow-y: auto; padding: 5px;',
              uiOutput(ns('slider3')) |> shinycssloaders$withSpinner(color = 'lightblue')
            )
      ),  
      footer = uiOutput(ns('uiFooter'))))
    
    output$uiFooter <- renderUI({
      
      current <- sliderPosition()
      
      if(current == 1){
        tagList(actionButton(ns("btSair"), label = "Sair"),
        actionButton(ns('btClear'), "Limpar", icon = icon("eraser")),
        actionButton(ns('btSalvar'),class = "btn-success",label = "Avançar",icon = icon("arrow-right")))
      }
      else{
        tagList(actionButton(ns("btSair"), label = "Voltar",icon = icon("arrow-left")),
        actionButton(ns('btSalvar'),class = "btn-success",label = "Avançar",icon = icon("arrow-right")))
      }
      
    })
   
    output$titleTexto <- renderText({
      
       if(!is.null(componenteReactive())){
         'Novo Componente'
       }
       else if(sliderPosition() == 1L){
        'Nova Objeto'
      }else{
        'Novos Componentes'
      }

    })
   
   output$slider1 <- renderUI({
     
     changetextPlaceHolder()
     
     div(
        inlineCSS(paste0("#",ns("textNameObjeto")," {text-transform: uppercase;}")),
        textInput(paste0(ns('textNameObjeto')),label = 'Nome',placeholder = 'Digite o nome para o Objeto'),
        br(),
        multiInput(
          inputId = ns('multiCameras'),
          width = '100%',
          options = list(
            enable_search = T,
            non_selected_header = "Câmeras não selecionados",
            selected_header     = "Câmeras selecionados"
          ),
          selected = NULL,
          label = "Câmeras ativas",
          choices = NULL,
          choiceNames  = apply(cameras(),1, function(x)  tagList(x["NAME_CAMERA"])),
          choiceValues = apply(cameras(),1, function(x)  x["NAME_CAMERA"])
        ) |> tagAppendAttributes(style = ';height: auto; width: 100%;')
      )
      
   })

   output$slider2 <- renderUI({
     
       req(sliderPosition() == 2L)
       camerasTargets <- isolate(input$multiCameras) 
       
        obs2$clear()
 
          # Captura novo polígono desenhado
        obs2$add(observeEvent(input$mapFrame_draw_new_feature, {

          feat <- input$mapFrame_draw_new_feature

          if(is.null(feat)) return()
          if(!identical(feat$geometry$type, "Polygon")) return()

          cameraTarget <- isolate({
            cameras() |> filter(NAME_CAMERA == input$comboCameras)
          })
         
          # GeoJSON coords: list(list(c(lng,lat), ...))
          coords <- feat$geometry$coordinates[[1]]
          lng    <- vapply(coords, function(x) x[[1]], numeric(1))
          lat    <- vapply(coords, function(x) x[[2]], numeric(1))
          poly   <- tibble(x = lng, y = lat)

          # Remove possível ponto duplicado final (= inicial)
          if(nrow(poly) >= 2 && isTRUE(all(poly[1, ] == poly[nrow(poly), ]))) {
            poly <- poly[-nrow(poly), ]
          }

          # Mantém só 1 polígono atual (último desenhado)
          if (is.null(rv$poly)) {
            rv$poly <- tibble(
              id = feat$properties$`_leaflet_id`,
              camera_id = cameraTarget$CD_ID_CAMERA,
              poligno = list(poly),
              atributos = list()
            )
          } else {
            rv$poly <- rbind(
              rv$poly,
              tibble(
                id = feat$properties$`_leaflet_id`,
                camera_id = cameraTarget$CD_ID_CAMERA,
                poligno = list(poly),
                atributos = list()
              )
            )
          }

        },ignoreInit = T))

        # Captura edições (mover vértices, etc.)
        obs2$add(observeEvent(input$mapFrame_draw_edited_features, {

          feats <- input$mapFrame_draw_edited_features
          cameraTarget <- isolate({
            cameras() |> filter(NAME_CAMERA == input$comboCameras)
          })

          if (is.null(feats$features) || length(feats$features) == 0) return()
          
          for(i in seq_along(feats$features)){

            feat <- feats$features[[i]]
            #if (!identical(feat$geometry$type, "Polygon")) return()
            id_    <- feat$properties$`_leaflet_id`
            coords <- feat$geometry$coordinates[[1]]
            lng  <- vapply(coords, function(x) x[[1]], numeric(1))
            lat  <- vapply(coords, function(x) x[[2]], numeric(1))
            poly <- tibble(x = lng, y = lat)
            if (nrow(poly) >= 2 && isTRUE(all(poly[1, ] == poly[nrow(poly), ]))) {
              poly <- poly[-nrow(poly), ]
            }
            rv$poly$poligno[[which(rv$poly$id == id_)]] <- poly
          }

        },ignoreInit = T))
     
       obs2$add(observeEvent(input$mapFrame_draw_deleted_features, {
         
          feats <- input$mapFrame_draw_deleted_features

          for(i in seq_along(feats$features)){

            feat <- feats$features[[i]]
            #if (!identical(feat$geometry$type, "Polygon")) return()
            id_     <- feat$properties$`_leaflet_id`
            rv$poly <- rv$poly[-which(rv$poly$id == id_),]
           }
      
       },ignoreInit = TRUE))
     
       obs2$add(observeEvent(input$mapFrame_shape_draw_click, {
         
          ev <- input$mapFrame_shape_draw_click
          if (is.null(ev$latlngs) || length(ev$latlngs) < 1) return()
         
         componenteReactive(rv$poly |> filter(id == ev$id))
         swiperSlideNext(idSwiper)
          
       },ignoreNULL = T,ignoreInit = T))

        # Limpa desenhos
        # obs2$add(observeEvent(input$clear, {
        #   leafletProxy("map") |> clearGroup("draw")
        #   rv$poly         <- NULL
        #   rv$cropped_path <- NULL
        # }))

        # Recorta dentro do polígono
        # obs2$add(observeEvent(input$save_poly, {
        #   req(rv$img, rv$w, rv$h, rv$poly)

        #     poly <- rv$poly

        #     # IMPORTANTE: Em magick::image_draw, o eixo Y cresce para cima (como plot base).
        #     # Já no Leaflet CRS.Simple, y (lat) cresce para baixo (pixels).
        #     # Por isso, precisamos espelhar Y: y_plot = h - y_leaflet
        #     y_plot <- rv$h - poly$y
        #     x_plot <- poly$x

        #     # 1) Cria uma máscara RGBA: polígono branco sobre fundo preto
        #     # mask <- image_blank(rv$w, rv$h, color = "black")
        #     # imgd <- image_draw(mask)
        #     # polygon(x_plot, y_plot, col = "white", border = NA)
        #     # dev.off()
 
        #     # image_write(imgd,"poligno.jpeg")

        # },ignoreInit = TRUE))
     
        output$mapFrame <- renderLeaflet({

          req(rv$w, rv$h, rv$img_path)
          data_uri <- base64enc$dataURI(file = rv$img_path, mime = "image/png")
     
          leaflet(options = leafletOptions(
              crs = leafletCRS(crsClass = "L.CRS.Simple"),
              zoomSnap  = 0,        # permite zoom fracionário
              zoomDelta = 0.25      # passo de zoom ao usar scroll
            )) |>
          addDrawToolbar(
            targetGroup = "draw",
            polylineOptions      = FALSE,
            circleMarkerOptions  = FALSE,
            markerOptions        = FALSE,
            # HABILITA polígono
            polygonOptions = drawPolygonOptions(
              shapeOptions = drawShapeOptions(fillOpacity = 0.2, weight = 2)
            ),
            # HABILITA retângulo
            rectangleOptions = drawRectangleOptions(
              shapeOptions = drawShapeOptions(fillOpacity = 0.2, weight = 2)
            ),
            # HABILITA círculo
            circleOptions = FALSE,
            editOptions = editToolbarOptions(
              selectedPathOptions = selectedPathOptions()
            )
          ) |>
          htmlwidgets$onRender(
            "
               function(el, x, data){
                var map = this;
                var bounds = [[0,0], [data.h, data.w]];   // [[0,0],[512,512]]

                // overlay da imagem
                L.imageOverlay(data.imageUrl, bounds, {opacity: 1}).addTo(map);

                // função que calcula o zoom para caber 100% da imagem (largura e altura)
                function fitWholeImage(){
                  // tamanho do viewport atual
                  var size  = map.getSize();
                  var scaleX = size.x / data.w;  // quanto cabe na largura
                  var scaleY = size.y / data.h;  // quanto cabe na altura
                  var scale  = Math.min(scaleX, scaleY);

                  // CRS.Simple usa potências de 2
                  var targetZoom = Math.log2(scale);
                  if (!isFinite(targetZoom)) targetZoom = 0;

                  // centraliza e aplica zoom
                  var center = [data.h/2, data.w/2];
                  map.setView(center, targetZoom, {animate:false});

                  // prende o mapa aos bounds da imagem
                  map.setMaxBounds(bounds);
                  map.options.maxBoundsViscosity = 1.0;

                  // impede 'zoom out' que faria sobrar bordas além da imagem
                  map.setMinZoom(targetZoom);

                  // garante cálculo correto após render
                  setTimeout(function(){ map.invalidateSize(); }, 0);
                }

                fitWholeImage();
                map.on('resize', fitWholeImage); // reencaixa se a janela mudar de tamanho
              }
            ",
            data = list(imageUrl = data_uri, w = rv$w, h = rv$h)
          )
        })
  
       tagList(
         selectInput(ns('comboCameras'),label = 'Câmera',choices = camerasTargets,selectize = FALSE),
        # div(
        #   id = ns("mapParent"),
        #   style = 'height: 512px; width: 100%;',     # o pai define a altura
        #   leafletOutput(ns("mapFrame"), height = "100%", width = "100%")  # o mapa preenche
        # )
          leafletOutput(ns("mapFrame"), height = "512px", width = "100%")
       )
     
   })

   output$slider3 <- renderUI({

     req(componenteReactive())
     
     #for(i in 1:5){
        i = 1
        div(
        inlineCSS(paste0("#",ns("textNameComponente")," {text-transform: uppercase;}")),
        splitLayout(
          cellWidths = c("80%", "20%"),
          textInput(paste0(ns('textNameComponente')),label = 'Nome',placeholder = 'Digite o nome para o componente'),
          actionButton(ns(paste0('atributoAdd')),label = '',icon = icon('plus'),style = 'margin-top: 25px;')
        ),
        br(),
        panelTitle(title = paste0("Atributo: ",1),
                   background.color.title = 'white',
                   title.color  = 'black',
                   border.color = 'lightgray',
                   children =   div(style = "margin-top: 10px; margin-left: 10px;",
          inlineCSS(paste0("#",ns(paste0('Atributo_',i))," {text-transform: uppercase;}")),
          br(),
          splitLayout(
            style = " overflow-x: auto",
            tagList(
              tags$label('Ativar',style = 'font-size: 15px;'),
              prettyToggle(
                inputId = paste0('checkboxAtributoAtivo_',i),
                label_on = "Sim",
                label_off = "Não", 
                outline = TRUE,
                plain = TRUE,
                value = TRUE,
                icon_on = icon("thumbs-up"),
                icon_off = icon("thumbs-down"),
                bigger = T,
                width = 'auto'
              )
            ),
            textInput(inputId = ns(paste0('atributo_',i)),label = paste0('Nome'),width = '100%',placeholder = "Nome para atributo"),
            selectInput(ns(paste0('comboTipodados_',i)),label = 'Tipo',choices = tipoDatas$NAME_DATA),
            actionButton(ns(paste0('atributoDel_',i)),label = '',icon = icon('trash'),style = 'margin-top: 25px;'),
            cellWidths = c('50px','200px','150px','50px')
          ),
          column(12,uiOutput(ns(paste0('container_',i)),style = 'padding: 5px;'))
        )))

     #}
       
   })

   # Sair 
   obs$add(observeEvent(input$btSair,{
      
      current <- isolate(sliderPosition())
     
      if(current == 1L){
         obs$destroy()
         obs2$destroy()
         removeModal(session)
      }else{
        if(is.null(isolate(componenteReactive())))
        sliderPosition(isolate(sliderPosition()) - 1L)
        swiperSlidePrevious(idSwiper)
        componenteReactive(NULL)
      }
      
   },ignoreInit = T,ignoreNULL = T))
   
   ## Clear
  obs$add(observeEvent(input$btClear, {
     updateTextInput(session,'textNameObjeto', value = '')
     updateMultiInput(session,'multiCameras',choices = '')
  }, ignoreInit = TRUE))

   ## Salvar Objeto
   obs$add(observeEvent(input$btSalvar,{

     current <- isolate(sliderPosition())

     if(current == 1L){
      nomeObjeto     <- isolate(toupper(input$textNameObjeto))
      camerasTargets <- isolate(input$multiCameras) 
  
      if(stringi$stri_isempty(stringr$str_trim(nomeObjeto))){
        showNotification("O nome do Objeto não foi preenchido!", type = "warning")
        return()
      }
              
      if(length(camerasTargets) == 0){
        showNotification("Nenhuma câmera foi selecionada para objeto!", type = "warning")
        return()
      }

      db$tryResetConnection(con,function(conn){

        con <<- conn
      
        if(checkifExistNameObjeto(con,nomeObjeto)){
          showNotification("O nome do Objeto já possui nos registros!", type = "warning")
          return()
        }

        dados <- selectAllFrame(con)

        # Carrega imagem
        img    <- image_read(dados$DATA_FRAME[[1]])
        info   <- image_info(img)
        rv$img <- img
        rv$w <- info$width
        rv$h <- info$height

        # Gera um PNG em temp e um dataURI (para overlay no Leaflet)
        tmp_png <- tempfile(fileext = ".png")
        image_write(img, path = tmp_png, format = "png")
        rv$img_path <- tmp_png

        sliderPosition(isolate(sliderPosition()) + 1L)
        swiperSlideNext(idSwiper)
      })
     
  }else if(current == 2L){

    df_poly <- isolate(rv$poly)

    if(is.null(df_poly)){
        showNotification("Nenhum desenho de poligno foi encontrado!", type = "warning")
        return()
    }else if(nrow(df_poly) == 0){
        showNotification("Nenhum desenho de poligno foi encontrado!", type = "warning")
        return()
    }
    #debugLocal(function(x){rv})
    #jsonlite::toJSON(df_poly$poligno[[1]],auto_unbox = T)
  }

   },ignoreInit = T,ignoreNULL = T))
   
 }
 
#' @export
uiEditObjeto <- function(ns,input,output,session,callback = NULL){

  #open database
  con <- db$newConnection()

  obs <- newObserve()
  sliderPosition <- reactiveVal(1L)
  idSwiper       <- ns('swiperMain')

  objetos        <- reactiveVal(selectAllObjetos(con))
  objeto         <- reactiveVal(NULL)

  showModal(
    session = session,
    dialogModal(
      title = textOutput(ns("titleTexto")),
      size = 'm',
      swiper(id = idSwiper,width = '100%',height = '350px',
            swiperSlide(
              style = 'height: 100%; width: 100%; overflow-y: hidden; padding: 5px;',
              uiOutput(ns('slider1'))
            ),
            swiperSlide(
              uiOutput(ns('slider2')) |> shinycssloaders$withSpinner(color = 'lightblue')
            )
      ),  
      footer = uiOutput(ns('uiFooter'))))
    
    output$uiFooter <- renderUI({
      
      current <- sliderPosition()
      
      if(current == 1){
        tagList(actionButton(ns("btSair"), label = "Sair"))
      }
      else{
        tagList(actionButton(ns("btSair"), label = "Voltar"),actionButton(ns('btActionUpdate'),class = "btn-warning",label = "Atualizar",icon = icon("save")))
      }
      
    })
  
    output$titleTexto <- renderText({
      
      if(sliderPosition() == 1L){
        'Registros Objetos'
      }else{
        'Edição da camerâ'
      }

    })
  
    output$slider1 <- renderUI({
      
      output$tableDinamica <- DT$renderDataTable({
     
        dataset  <- objetos()

        if(length(dataset) == 0) return(NULL)
        
        colunaNames <- c('LINHA','SETOR',"URL",'VISUALIZAR / EDITAR','REMOVER')
      
        DT$datatable({
          
          dataset |> 
            mutate_if(is.POSIXct,function(x){ format(x,'%d/%m/%Y %H:%M:%S')})  |> 
            mutate_if(is.Date,function(x){ format(x,'%d/%m/%Y')}) |> 
            mutate_if(is.character,toupper) |> 
            mutate(
                  !!colunaNames[1] := 1:nrow(dataset),
                  !!colunaNames[2] :=  dataset$NAME_CAMERA,
                  !!colunaNames[3] :=  dataset$URL_CAMERA,
                  !!colunaNames[4] :=  sapply(dataset$CD_ID_CAMERA, function (x) {
                    
                   as.character(
                      actionButton(
                        paste0(ns('btEdit')),
                        label = '',
                        icon = icon('eye'),
                        onclick = paste0('Shiny.setInputValue(\"',ns("editPressedRow"),'\","',x,'",{priority: "event"})'),
                        #style = 'background-color: transparent; color: lightblue; border-solid: none;'
                      )
                    )
                  }),
                  !!colunaNames[5] :=  sapply(dataset$CD_ID_CAMERA, function (x) {
                    
                   as.character(
                      actionButton(
                        paste0(ns('btRemove')),
                        label = '',
                        icon = icon('trash'),
                        onclick = paste0('Shiny.setInputValue(\"',ns("deletePressedRow"),'\","',x,'",{priority: "event"})'),
                        #style = 'background-color: transparent; color: lightblue; border-solid: none;'
                      )
                    )
                  })
                  
            ) |> select(colunaNames) |> arrange(colunaNames[2])
        },  
        class = 'cell-border stripe',
        extensions = 'Scroller',
        options = list(
          language = list(url = 'js/table.json'),
          dom = 't',
          bSort=FALSE,
          columnDefs = list(list(visible=FALSE, targets=c(0)),list(className = 'dt-center', targets = "_all"),list(width = '75px',targets = c(1,4)),list(width = 'autos',targets = c(3))),
          deferRender = TRUE,
          scroller = FALSE,
          fixedHeader = TRUE,
          scrollX = TRUE,
          scrollY = '380px'
        ),
        escape = F,
        selection = 'none',
        ) |> DT$formatStyle(colunaNames, cursor = 'pointer')
        
      })
      
      div(
        style = 'border-style: solid; border-color: white; border-width: 1px; overflow-x: auto;',
        DT$dataTableOutput(outputId = ns('tableDinamica'))
      )
      
    })
  
  output$slider2 <- renderUI({

    req(objeto())
    objetoSelect <- objeto()

      div(
        inlineCSS(paste0("#",ns("textNameObjeto")," {text-transform: uppercase;}")),
        textInput(paste0(ns('textNameObjeto')),label = 'Nome',placeholder = 'Digite o nome para o Objeto',value = objetoSelect$NAME_CAMERA),
        br(),
        panelTitle(title = "Configuração",
                   background.color.title = 'white',
                   title.color  = 'black',
                   border.color = 'lightgray',
                   children = fluidRow(
                     style = 'padding-top: 10px; padding-left: 15px; padding-right: 15px;',
                     column(6,textInput(ns('textUrlObjeto'),label = 'Url',placeholder = 'rtsp://...',value = objetoSelect$URL_CAMERA)),
                     column(6,selectInput(ns('comboFps'),label = 'Frame por segundos',choices = c(1,5,15,30),selected = objetoSelect$FPS_CAMERA))
                   )
        )
      )

  })

  obs$add(observeEvent(input$editPressedRow,{
    
    objeto(isolate(objetos()) %>% filter(CD_ID_CAMERA == input$editPressedRow))

    swiperSlideNext(idSwiper)
    sliderPosition(isolate(sliderPosition()) + 1L)
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$deletePressedRow,{
    
    objeto <- isolate(objetos()) |> filter(CD_ID_CAMERA == input$deletePressedRow)

    messageAlerta(
                  input,
                  ns,
                  title   = paste0('Todos os objetos ligado a esse camerâ será excluido'),
                  message = paste0('Deseja realmente excluir a camerâ ',objeto$NAME_CAMERA,"?"),
                  callback.no = function(){
                    
                  },
                  callback.yes = function(){
                    
                    db$tryResetConnection(con,function(conn){
                      
                      con <<- conn
                      deleteObjeto(con,objeto$CD_ID_CAMERA)
                      objetos.aux <- selectAllObjetos(con)
                      if(nrow(objetos.aux) == 0){
                        #destroy all observe events
                        obs$destroy()
                        removeModal(session)
                        db$closerDatabase(con)
                        callback(NULL)
                      }else{
                        objetos(objetos.aux)
                      }
                      
                    })

                  })
    
  },ignoreInit = T))
  

  obs$add(observeEvent(input$btSair,{
    
    current <- isolate(sliderPosition())

    if(current == 1){
      #destroy all observe events
      obs$destroy()
      swiperDestroy(idSwiper)
      removeModal(session)
      db$closerDatabase(con)
    }
    else{
      objeto(NULL)
      swiperSlidePrevious(idSwiper)
      sliderPosition(current - 1L)
    }
    
  },ignoreInit = T))
  
  obs$add(observeEvent(input$btActionUpdate,{
    
    req(objeto())

    id         <- isolate(objeto()$CD_ID_CAMERA)
    nomeObjeto <- isolate(toupper(input$textNameObjeto))
    urlObjeto  <- isolate(input$textUrlObjeto)

    if(stringi$stri_isempty(stringr$str_trim(nomeObjeto))){
      showNotification("O nome do Objeto não foi preenchido!", type = "warning")
      return()
    }
    
    if(checkifExistNameObjetoEdit(con = con,id,name = nomeObjeto)){
      showNotification("O nome do Objeto já possui nos registros!", type = "warning")
    }
    if(stringi$stri_isempty(stringr$str_trim(urlObjeto))){
      showNotification("O url da Objeto não foi preenchido!", type = "warning")
      return()
    }
    if(checkifExistUrlObjetoEdit (con = con,id,urlObjeto)){
      showNotification("O url da Objeto já possui nos registros!", type = "warning")
      return()
    }
    #check if it has already data of Objeto
    obj <- list()
    obj$CD_ID_CAMERA  <- id
    obj$NAME_CAMERA   <- nomeObjeto
    obj$URL_CAMERA    <- urlObjeto
    obj$FPS_CAMERA    <- isolate(input$comboFps)

    db$tryResetConnection(con,function(conn){
  
      con <<- conn
      updateObjeto(conn,obj)
      #load todos os setores
      objetos(selectAllObjetos(conn))
  
      swiperSlidePrevious(idSwiper)
      sliderPosition(isolate(sliderPosition()) - 1L)

      showNotification("camerâ atualizado com sucesso!", type = "warning")
    })
    
  },ignoreInit = T))
  
}
