box::use(
  shiny[moduleServer, NS, div, h3]
)

#' @export
ui <- function(id, title = "Em construção") {
  NS(id) # garante namespace
  div(
    class = "page-wrapper",
    h3(class = "placeholder-title", title),
    div(class = "center-loader", div(class = "ui active loader")),
    div(class = "pane-content muted", "Em construção…")
  )
}

#' @export
server <- function(id) {
  moduleServer(id, function(input, output, session) {})
}
