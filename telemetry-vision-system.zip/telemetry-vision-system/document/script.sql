-- =========================================================
-- CONFIG INICIAL
-- =========================================================
SET NAMES utf8mb4;
SET time_zone = '+00:00';
SET sql_safe_updates = 0;

-- Ativa agendador (requer privilégio adequado)
SET GLOBAL event_scheduler = ON;

-- =========================================================
-- DROP ORDEM CORRETA
-- =========================================================
DROP EVENT       IF EXISTS AG_BY_1_DAY;
DROP PROCEDURE   IF EXISTS PR_CLEAR_OLD_DATAS;

DROP TABLE IF EXISTS OBJETO_VIEW;
DROP TABLE IF EXISTS ATRIBUTO;
DROP TABLE IF EXISTS TIPO_DATA;
DROP TABLE IF EXISTS COMPONENTE;
DROP TABLE IF EXISTS OBJETO;
DROP TABLE IF EXISTS FRAME_CAMERA;
DROP TABLE IF EXISTS CAMERA_CONFIG;
DROP TABLE IF EXISTS CAMERA_VIEW;
DROP TABLE IF EXISTS SETOR;

-- =========================================================
-- CRIAÇÃO DE TABELAS (InnoDB + utf8mb4)
-- =========================================================
CREATE TABLE IF NOT EXISTS SETOR (
  CD_ID_SETOR                 INT          NOT NULL AUTO_INCREMENT PRIMARY KEY,
  NAME_SETOR                  VARCHAR(50)  NOT NULL,
  TEMPO_REATIVAR_SETOR        INT          NOT NULL,
  TEMPO_REATIVAR_UNIDADE_SETOR VARCHAR(50) NOT NULL,
  TEMPO_PASSADO_SETOR         INT          NOT NULL,
  TEMPO_PASSADO_UNIDADE_SETOR VARCHAR(50)  NOT NULL,
  CD_ID_USER                  INT,
  FG_ATIVO                    BOOLEAN      DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS CAMERA_VIEW (
  CD_ID_CAMERA  INT          NOT NULL AUTO_INCREMENT PRIMARY KEY,
  NAME_CAMERA   VARCHAR(100) NOT NULL,
  URL_CAMERA    VARCHAR(200) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS CAMERA_CONFIG (
  CD_ID_CAMERA_HIST  INT         NOT NULL AUTO_INCREMENT PRIMARY KEY,
  CD_ID_CAMERA       INT         NOT NULL,
  FPS_CAMERA         INT         NOT NULL,
  DT_HR_LOCAL        TIMESTAMP   NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_camcfg_camera
    FOREIGN KEY (CD_ID_CAMERA) REFERENCES CAMERA_VIEW(CD_ID_CAMERA)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS FRAME_CAMERA (
  CD_ID_FRAME   INT        NOT NULL AUTO_INCREMENT PRIMARY KEY,
  DATA_FRAME    LONGBLOB   NOT NULL,
  DT_HR_LOCAL   TIMESTAMP  NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CD_ID_CAMERA  INT        NOT NULL,
  CONSTRAINT fk_frame_camera
    FOREIGN KEY (CD_ID_CAMERA) REFERENCES CAMERA_VIEW(CD_ID_CAMERA)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS OBJETO (
  CD_ID_OBJETO  INT         NOT NULL AUTO_INCREMENT PRIMARY KEY,
  NAME_OBJETO   VARCHAR(100) NOT NULL,
  CD_ID_SETOR   INT         NOT NULL,
  CONSTRAINT fk_obj_setor
    FOREIGN KEY (CD_ID_SETOR) REFERENCES SETOR(CD_ID_SETOR)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS COMPONENTE (
  CD_ID_COMPONENTE  INT         NOT NULL AUTO_INCREMENT PRIMARY KEY,
  NAME_COMPONENTE   VARCHAR(100) NOT NULL,
  CD_ID_OBJETO      INT         NOT NULL,
  CONSTRAINT fk_comp_obj
    FOREIGN KEY (CD_ID_OBJETO) REFERENCES OBJETO(CD_ID_OBJETO)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Qualitativo (categorical)
-- Nominal: categorias sem ordem (cor dos olhos).
-- Ordinal: categorias com ordem (nível de satisfação: baixo/médio/alto).
-- Binário/Dicotômico: duas categorias (sim/não).
-- Quantitativo (numérico)
-- Discreto: contagens inteiras (número de defeitos).
-- Contínuo: medidas em escala contínua (altura, tempo).
CREATE TABLE IF NOT EXISTS TIPO_DATA (
  CD_ID_DATA  INT          NOT NULL AUTO_INCREMENT PRIMARY KEY,
  NAME_DATA   VARCHAR(100) NOT NULL,
  R_DATA      TEXT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS ATRIBUTO (
  CD_ID_ATRIBUTO    INT          NOT NULL AUTO_INCREMENT PRIMARY KEY,
  CD_ID_COMPONENTE  INT          NOT NULL,
  NAME_ATRIBUTO     VARCHAR(100) NOT NULL,
  FG_ATIVO          BOOLEAN      DEFAULT 0,
  CD_ID_DATA        INT          NOT NULL,
  CONSTRAINT fk_attr_data
    FOREIGN KEY (CD_ID_DATA) REFERENCES TIPO_DATA(CD_ID_DATA),
  CONSTRAINT fk_attr_comp
    FOREIGN KEY (CD_ID_COMPONENTE) REFERENCES COMPONENTE(CD_ID_COMPONENTE)
    ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS OBJETO_VIEW (
  CD_ID_OV     INT          NOT NULL AUTO_INCREMENT PRIMARY KEY,
  NAME_OV      VARCHAR(100) NOT NULL,
  CD_ID_CAMERA INT          NOT NULL,
  CD_ID_OBJETO INT          NOT NULL,
  FG_ATIVO     BOOLEAN      DEFAULT 0,
  CONSTRAINT fk_objv_camera
    FOREIGN KEY (CD_ID_CAMERA) REFERENCES CAMERA_VIEW(CD_ID_CAMERA),
  CONSTRAINT fk_objv_obj
    FOREIGN KEY (CD_ID_OBJETO) REFERENCES OBJETO(CD_ID_OBJETO)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =========================================================
-- ÍNDICES PARA PERFORMANCE
-- =========================================================

-- FRAME_CAMERA: filtros por câmera + período, e "último frame" por câmera
ALTER TABLE FRAME_CAMERA
  ADD INDEX idx_frame_cam_dt (CD_ID_CAMERA, DT_HR_LOCAL),
  ADD INDEX idx_frame_dt (DT_HR_LOCAL),
  ADD INDEX idx_frame_cam_dt_id (CD_ID_CAMERA, DT_HR_LOCAL, CD_ID_FRAME);

-- CAMERA_CONFIG: pegar a config mais recente por câmera
ALTER TABLE CAMERA_CONFIG
  ADD INDEX idx_camcfg_cam_dt (CD_ID_CAMERA, DT_HR_LOCAL);

-- OBJETO_VIEW: consultas por câmera/objeto/ativo
ALTER TABLE OBJETO_VIEW
  ADD INDEX idx_objv_cam_obj_ativo (CD_ID_CAMERA, CD_ID_OBJETO, FG_ATIVO);

-- Chaves estrangeiras comuns para joins
ALTER TABLE OBJETO
  ADD INDEX idx_obj_setor (CD_ID_SETOR);

ALTER TABLE COMPONENTE
  ADD INDEX idx_comp_obj (CD_ID_OBJETO);

ALTER TABLE ATRIBUTO
  ADD INDEX idx_attr_comp (CD_ID_COMPONENTE),
  ADD INDEX idx_attr_data (CD_ID_DATA),
  ADD INDEX idx_attr_comp_ativo (CD_ID_COMPONENTE, FG_ATIVO);

-- =========================================================
-- PROCEDURE DE LIMPEZA (retém N dias; usa delete em lotes)
-- =========================================================
DELIMITER $$

CREATE PROCEDURE PR_CLEAR_OLD_DATAS(IN p_keep_days INT)
BEGIN
  DECLARE v_rows INT DEFAULT 1;

  -- Deleta frames antigos em lotes para evitar long locks e binlogs gigantes
  WHILE v_rows > 0 DO
    DELETE FROM FRAME_CAMERA
     WHERE DT_HR_LOCAL < (NOW() - INTERVAL p_keep_days DAY)
     LIMIT 10000;
    SET v_rows = ROW_COUNT();
  END WHILE;

  -- (Opcional) Manter apenas configs dos últimos N dias (ou com outra regra):
  -- SET v_rows = 1;
  -- WHILE v_rows > 0 DO
  --   DELETE FROM CAMERA_CONFIG
  --    WHERE DT_HR_LOCAL < (NOW() - INTERVAL p_keep_days DAY)
  --    LIMIT 10000;
  --   SET v_rows = ROW_COUNT();
  -- END WHILE;
END$$

DELIMITER ;

-- =========================================================
-- EVENTO DIÁRIO PARA LIMPEZA AUTOMÁTICA
-- =========================================================
-- Ajuste INTERVAL 30 DAY para o período desejado
CREATE EVENT IF NOT EXISTS AG_BY_1_DAY
  ON SCHEDULE EVERY 1 DAY
  STARTS CURRENT_TIMESTAMP + INTERVAL 1 DAY
  DO
    CALL PR_CLEAR_OLD_DATAS(30);

-- INSERT DAFAULT 
INSERT INTO TIPO_DATA (NAME_DATA,R_DATA) VALUES('QUALITATIVO','text');    
INSERT INTO TIPO_DATA (NAME_DATA,R_DATA) VALUES('QUANTITATIVO','text');  