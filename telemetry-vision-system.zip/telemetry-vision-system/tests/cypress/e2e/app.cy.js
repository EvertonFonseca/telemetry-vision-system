describe('app', () => {
  beforeEach(() => {
    cy.visit('/')
  })

  it('starts', () => {})
})
